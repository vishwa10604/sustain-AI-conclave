package com.greenops.fleet.service;

import com.greenops.fleet.model.DriverInspection;
import com.greenops.fleet.model.UserAccount;
import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.repository.FleetRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AuthServiceTest {

    private FleetRepository repository;
    private AuthService authService;

    @BeforeEach
    void setUp() {
        repository = new FleetRepository();
        authService = new AuthService(repository);

        // Seed users
        repository.saveUser(new UserAccount(
                "usr-owner-01", "owner@greenoops.com", "S. Harikumaran", "Owner@123",
                "VEHICLE_OWNER", true, "RC-TN-GO-77821", "ALL_FLEET", null
        ));
        repository.saveUser(new UserAccount(
                "usr-driver-01", "driver@greenoops.com", "Ramesh Kumar", "Driver@123",
                "DRIVER", true, "DL-TN-38-2018-99214", "TN-38-AB-1234", 1L
        ));

        // Seed vehicle
        repository.saveVehicle(new Vehicle(1L, "TN-38-AB-1234", "Truck", "Diesel", 2021, 145000, null));
    }

    @Test
    @DisplayName("Valid owner login returns token and role VEHICLE_OWNER")
    void testValidOwnerLogin() {
        Map<String, Object> result = authService.login("owner@greenoops.com", "Owner@123");
        assertNotNull(result.get("token"));
        assertEquals("VEHICLE_OWNER", result.get("role"));
        assertEquals("S. Harikumaran", result.get("name"));
        assertTrue((Boolean) result.get("verified"));
    }

    @Test
    @DisplayName("Valid driver login returns token and role DRIVER")
    void testValidDriverLogin() {
        Map<String, Object> result = authService.login("driver@greenoops.com", "Driver@123");
        assertNotNull(result.get("token"));
        assertEquals("DRIVER", result.get("role"));
        assertEquals("Ramesh Kumar", result.get("name"));
        assertEquals("TN-38-AB-1234", result.get("assignedVehicleReg"));
    }

    @Test
    @DisplayName("Invalid password throws UNAUTHORIZED exception")
    void testInvalidPassword() {
        assertThrows(ResponseStatusException.class, () ->
                authService.login("owner@greenoops.com", "WrongPassword"));
    }

    @Test
    @DisplayName("Driver inspection with defects triggers ACTION_REQUIRED verdict and notification")
    void testDefectInspection() {
        DriverInspection insp = new DriverInspection(
                null, 1L, "Ramesh Kumar", null,
                false, true, false, true, 145200, "Brakes spongy", null, null
        );

        DriverInspection saved = authService.submitInspection(insp);
        assertEquals("ACTION_REQUIRED", saved.safetyVerdict());
        assertEquals("TN-38-AB-1234", saved.vehicleReg());

        // Verify automated notification created
        assertFalse(repository.findAllNotifications().isEmpty());
        assertTrue(repository.findAllNotifications().stream()
                .anyMatch(n -> n.priority().equals("CRITICAL") && n.message().contains("Brakes spongy")));
    }

    @Test
    @DisplayName("Driver inspection all passed triggers CLEARED_FOR_ROUTE verdict")
    void testClearedInspection() {
        DriverInspection insp = new DriverInspection(
                null, 1L, "Ramesh Kumar", "TN-38-AB-1234",
                true, true, true, true, 145200, "All checked and roadworthy", null, null
        );

        DriverInspection saved = authService.submitInspection(insp);
        assertEquals("CLEARED_FOR_ROUTE", saved.safetyVerdict());
    }
}
