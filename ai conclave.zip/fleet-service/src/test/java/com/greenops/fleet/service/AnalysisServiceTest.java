package com.greenops.fleet.service;

import com.greenops.fleet.model.FleetAnalysisReport;
import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.repository.FleetRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class AnalysisServiceTest {

    private FleetRepository repository;
    private AnalysisService analysisService;

    @BeforeEach
    void setUp() {
        repository = new FleetRepository();
        analysisService = new AnalysisService(repository);

        // Seed vehicles
        Vehicle v1 = new Vehicle(1L, "TN-38-AB-1234", "Truck", "Diesel", 2021, 145000, LocalDate.now().minusDays(195));
        Vehicle v2 = new Vehicle(2L, "TN-37-CD-5678", "Van", "Diesel", 2023, 42000, LocalDate.now().minusDays(45));
        repository.saveVehicle(v1);
        repository.saveVehicle(v2);
    }

    @Test
    @DisplayName("Generate fleet analysis report returns valid metrics and forecasts")
    void testGenerateAnalysisReport() {
        FleetAnalysisReport report = analysisService.generateAnalysisReport();

        assertNotNull(report);
        assertEquals(2, report.totalVehiclesMonitored());
        assertTrue(report.fleetAvailabilityRatePercent() > 90.0);
        assertTrue(report.meanTimeBetweenFailuresDays() > 0);
        assertEquals(4.8, report.maintenanceRoiMultiplier());

        // Forecasts
        assertFalse(report.predictiveForecasts().isEmpty());
        assertTrue(report.predictiveForecasts().stream().anyMatch(f -> f.componentName().contains("Brake")));

        // Driver Scorecards
        assertFalse(report.driverScorecards().isEmpty());
        assertTrue(report.driverScorecards().stream().anyMatch(d -> d.driverName().equals("Ramesh Kumar")));

        // Risk Correlation & Directives
        assertNotNull(report.riskFactorCorrelation());
        assertFalse(report.executiveAnalyticsDirectives().isEmpty());
    }
}
