package com.greenops.fleet.service;

import com.greenops.fleet.model.MaintenanceRecord;
import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.repository.FleetRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VehicleServiceTest {

    @Mock
    private FleetRepository repository;

    @InjectMocks
    private VehicleService vehicleService;

    private final LocalDate today = LocalDate.of(2026, 10, 10);

    @Test
    @DisplayName("getById throws 404 when vehicle is not found")
    void testGetByIdNotFound() {
        when(repository.findVehicleById(999L)).thenReturn(Optional.empty());
        assertThrows(ResponseStatusException.class, () -> vehicleService.getById(999L));
    }

    @Test
    @DisplayName("create throws BAD_REQUEST when registrationNumber is blank")
    void testCreateBlankReg() {
        Vehicle v = new Vehicle(null, "   ", "Truck", "Diesel", 2020, 10000, today.minusDays(10));
        assertThrows(ResponseStatusException.class, () -> vehicleService.create(v));
    }

    @Test
    @DisplayName("create throws BAD_REQUEST when odometer is negative")
    void testCreateNegativeOdometer() {
        Vehicle v = new Vehicle(null, "TN-01-XY-1234", "Truck", "Diesel", 2020, -100, today.minusDays(10));
        assertThrows(ResponseStatusException.class, () -> vehicleService.create(v));
    }

    @Test
    @DisplayName("create throws BAD_REQUEST when lastServiceDate is in the future")
    void testCreateFutureServiceDate() {
        Vehicle v = new Vehicle(null, "TN-01-XY-1234", "Truck", "Diesel", 2020, 10000, LocalDate.now().plusDays(5));
        assertThrows(ResponseStatusException.class, () -> vehicleService.create(v));
    }

    @Test
    @DisplayName("addMaintenance updates vehicle lastServiceDate when ROUTINE_SERVICE is later")
    void testRoutineServiceUpdatesVehicleLastServiceDate() {
        Vehicle initial = new Vehicle(1L, "TN-01-XY-1234", "Truck", "Diesel", 2020, 10000, today.minusDays(50));
        when(repository.findVehicleById(1L)).thenReturn(Optional.of(initial));

        MaintenanceRecord r = new MaintenanceRecord(null, 1L, today.minusDays(10), "ROUTINE_SERVICE", "Oil Change", 3000);
        when(repository.saveRecord(any())).thenAnswer(invocation -> invocation.getArgument(0));

        vehicleService.addMaintenance(1L, r);

        // Verify saveVehicle was called to update lastServiceDate to today.minusDays(10)
        verify(repository).saveVehicle(argThat(v -> v.lastServiceDate().equals(today.minusDays(10))));
    }

    @Test
    @DisplayName("addMaintenance does not update vehicle lastServiceDate for BREAKDOWN_REPAIR")
    void testBreakdownDoesNotUpdateLastServiceDate() {
        Vehicle initial = new Vehicle(1L, "TN-01-XY-1234", "Truck", "Diesel", 2020, 10000, today.minusDays(50));
        when(repository.findVehicleById(1L)).thenReturn(Optional.of(initial));

        MaintenanceRecord r = new MaintenanceRecord(null, 1L, today.minusDays(10), "BREAKDOWN_REPAIR", "Clutch", 5000);
        when(repository.saveRecord(any())).thenAnswer(invocation -> invocation.getArgument(0));

        vehicleService.addMaintenance(1L, r);

        // saveVehicle should NOT have been called
        verify(repository, never()).saveVehicle(any());
    }

    @Test
    @DisplayName("addMaintenance rejects negative cost")
    void testNegativeCostRejected() {
        Vehicle initial = new Vehicle(1L, "TN-01-XY-1234", "Truck", "Diesel", 2020, 10000, today.minusDays(50));
        when(repository.findVehicleById(1L)).thenReturn(Optional.of(initial));

        MaintenanceRecord r = new MaintenanceRecord(null, 1L, today.minusDays(10), "ROUTINE_SERVICE", "Check", -500);
        assertThrows(ResponseStatusException.class, () -> vehicleService.addMaintenance(1L, r));
    }
}
