package com.greenops.fleet.service;

import com.greenops.fleet.model.MaintenanceRecord;
import com.greenops.fleet.model.RiskReport;
import com.greenops.fleet.model.Vehicle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MaintenanceRiskServiceTest {

    @Mock
    private VehicleService vehicleService;

    @InjectMocks
    private MaintenanceRiskService riskService;

    private final LocalDate today = LocalDate.of(2026, 10, 10);

    @Test
    @DisplayName("Vehicle with no service date gets +30 risk points")
    void testNullServiceDate() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Truck", "Diesel", 2024, 20_000, null);
        RiskReport report = riskService.calculate(v, List.of(), today);

        assertEquals(30, report.riskScore());
        assertEquals("MEDIUM", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("No service date")));
    }

    @Test
    @DisplayName("Vehicle serviced 200 days ago (>180) gets +30 risk points")
    void testOldServiceDate() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Truck", "Diesel", 2024, 20_000, today.minusDays(200));
        RiskReport report = riskService.calculate(v, List.of(), today);

        assertEquals(30, report.riskScore());
        assertEquals("MEDIUM", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("200 days ago (+30)")));
    }

    @Test
    @DisplayName("Vehicle serviced 100 days ago (>90) gets +15 risk points")
    void testModerateServiceDate() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Truck", "Diesel", 2024, 20_000, today.minusDays(100));
        RiskReport report = riskService.calculate(v, List.of(), today);

        assertEquals(15, report.riskScore());
        assertEquals("LOW", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("100 days ago (+15)")));
    }

    @Test
    @DisplayName("Vehicle with high odometer (>150k km) gets +20 risk points")
    void testHighMileage() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Van", "Diesel", 2024, 160_000, today.minusDays(30));
        RiskReport report = riskService.calculate(v, List.of(), today);

        assertEquals(20, report.riskScore());
        assertEquals("LOW", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("High mileage")));
    }

    @Test
    @DisplayName("Vehicle with moderate odometer (>80k km) gets +10 risk points")
    void testModerateMileage() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Van", "Diesel", 2024, 95_000, today.minusDays(30));
        RiskReport report = riskService.calculate(v, List.of(), today);

        assertEquals(10, report.riskScore());
        assertEquals("LOW", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("Moderate mileage")));
    }

    @Test
    @DisplayName("Vehicle age >8 years gets +15 risk points")
    void testOldVehicleAge() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Bus", "Diesel", 2016, 50_000, today.minusDays(30));
        RiskReport report = riskService.calculate(v, List.of(), today);

        // 2026 - 2016 = 10 > 8 -> +15
        assertEquals(15, report.riskScore());
        assertEquals("LOW", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("Vehicle age 10 years (+15)")));
    }

    @Test
    @DisplayName("Vehicle age >5 years gets +8 risk points")
    void testModerateVehicleAge() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Bus", "Diesel", 2020, 50_000, today.minusDays(30));
        RiskReport report = riskService.calculate(v, List.of(), today);

        // 2026 - 2020 = 6 > 5 -> +8
        assertEquals(8, report.riskScore());
        assertEquals("LOW", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("Vehicle age 6 years (+8)")));
    }

    @Test
    @DisplayName("Breakdown repairs within 180 days add +10 each, capped at +25")
    void testBreakdownRepairsCappedAt25() {
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Truck", "Diesel", 2024, 30_000, today.minusDays(30));
        List<MaintenanceRecord> records = List.of(
                new MaintenanceRecord(1L, 1L, today.minusDays(20), "BREAKDOWN_REPAIR", "Brake fault", 5000),
                new MaintenanceRecord(2L, 1L, today.minusDays(50), "BREAKDOWN_REPAIR", "Clutch issue", 7000),
                new MaintenanceRecord(3L, 1L, today.minusDays(100), "BREAKDOWN_REPAIR", "Alternator issue", 8000),
                new MaintenanceRecord(4L, 1L, today.minusDays(200), "BREAKDOWN_REPAIR", "Old breakdown", 4000), // outside 180d
                new MaintenanceRecord(5L, 1L, today.minusDays(10), "ROUTINE_SERVICE", "Routine check", 2000)
        );

        RiskReport report = riskService.calculate(v, records, today);

        // 3 breakdowns in last 180 days -> 3 * 10 = 30 -> capped at 25
        assertEquals(25, report.riskScore());
        assertEquals("LOW", report.riskLevel());
        assertTrue(report.reasons().stream().anyMatch(r -> r.contains("3 breakdown repair(s) in last 180 days (+25)")));
    }

    @Test
    @DisplayName("High risk vehicle accumulation score capped at 100")
    void testCumulativeHighRiskAndCapAt100() {
        // days > 180 (+30), odometer > 150k (+20), age > 8 (+15), breakdowns 3 capped (+25) -> 30+20+15+25 = 90
        Vehicle v = new Vehicle(1L, "TN-01-AA-1111", "Truck", "Diesel", 2012, 220_000, today.minusDays(250));
        List<MaintenanceRecord> records = List.of(
                new MaintenanceRecord(1L, 1L, today.minusDays(20), "BREAKDOWN_REPAIR", "Engine issue", 15000),
                new MaintenanceRecord(2L, 1L, today.minusDays(60), "BREAKDOWN_REPAIR", "Transmission issue", 20000),
                new MaintenanceRecord(3L, 1L, today.minusDays(120), "BREAKDOWN_REPAIR", "Axle issue", 12000)
        );

        RiskReport report = riskService.calculate(v, records, today);
        assertEquals(90, report.riskScore());
        assertEquals("HIGH", report.riskLevel());
        assertEquals("Schedule maintenance immediately and consider taking the vehicle off route.", report.recommendation());
    }

    @Test
    @DisplayName("assessAll sorts vehicles in descending order of risk score")
    void testAssessAllSorting() {
        Vehicle vLow = new Vehicle(1L, "TN-01-LOW", "Car", "Electric", 2024, 10_000, today.minusDays(10));
        Vehicle vHigh = new Vehicle(2L, "TN-01-HIGH", "Truck", "Diesel", 2014, 180_000, today.minusDays(220));

        when(vehicleService.getAll()).thenReturn(List.of(vLow, vHigh));
        when(vehicleService.getMaintenance(1L)).thenReturn(List.of());
        when(vehicleService.getMaintenance(2L)).thenReturn(List.of());

        List<RiskReport> reports = riskService.assessAll();

        assertEquals(2, reports.size());
        assertEquals(2L, reports.get(0).vehicleId()); // high risk first
        assertEquals(1L, reports.get(1).vehicleId());
        assertTrue(reports.get(0).riskScore() > reports.get(1).riskScore());
    }
}
