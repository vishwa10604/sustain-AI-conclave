package com.greenops.fleet.controller;

import com.greenops.fleet.config.DataSeeder;
import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.repository.FleetRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DatabaseControllerTest {

    @Mock
    private FleetRepository repository;

    @Mock
    private DataSeeder dataSeeder;

    @InjectMocks
    private DatabaseController databaseController;

    @Test
    @DisplayName("getStatus returns database statistics and metrics")
    void testGetStatus() {
        when(repository.getDatabaseStatistics()).thenReturn(Map.of(
                "databaseType", "H2 Relational Database",
                "isDatabaseActive", true,
                "totalRecords", 42L
        ));

        Map<String, Object> result = databaseController.getStatus();
        assertNotNull(result);
        assertEquals("H2 Relational Database", result.get("databaseType"));
        assertEquals(42L, result.get("totalRecords"));
    }

    @Test
    @DisplayName("getTablePreview returns vehicle entities for vehicles table")
    void testGetTablePreviewVehicles() {
        Vehicle v = new Vehicle(1L, "TN-01-AB-1234", "Truck", "Diesel", 2021, 10000, null);
        when(repository.findAllVehicles()).thenReturn(List.of(v));

        List<?> list = databaseController.getTablePreview("vehicles");
        assertEquals(1, list.size());
        assertEquals(v, list.get(0));
    }

    @Test
    @DisplayName("resetDatabase invokes data seeder and returns stats")
    void testResetDatabase() {
        when(repository.getDatabaseStatistics()).thenReturn(Map.of("totalRecords", 50L));

        Map<String, Object> result = databaseController.resetDatabase();
        verify(dataSeeder, times(1)).run();
        assertNotNull(result);
        assertTrue(result.containsKey("message"));
    }
}
