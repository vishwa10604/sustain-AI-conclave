package com.greenops.fleet.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public record VehicleHealth(
        Long vehicleId,
        // Engine Oil
        Double oilLevelPercent,
        String oilPressureStatus, // NORMAL, WARNING, CRITICAL
        String oilCondition,       // GOOD, DEGRADED, NEEDS_FLUSH
        LocalDate lastOilChange,
        LocalDate nextOilChange,
        String oilMaintenanceStatus, // NORMAL, DUE_SOON, OVERDUE

        // Tire Monitoring
        double tirePressureFlPsi,
        double tirePressureFrPsi,
        double tirePressureRlPsi,
        double tirePressureRrPsi,
        double recommendedTirePressurePsi,
        double tireTreadFlMm,
        double tireTreadFrMm,
        double tireTreadRlMm,
        double tireTreadRrMm,
        String tireInspectionStatus, // NORMAL, WARNING, CRITICAL

        // Powertrain & Electronics
        double coolantTempCelsius,
        double batteryHealthPercent,
        double batteryVoltage,
        double brakePadFrontPercent,
        double brakePadRearPercent,
        String brakeFluidStatus, // NORMAL, SERVICE_REQUIRED
        List<String> diagnosticTroubleCodes, // e.g. ["P0300", "P0420"]
        double fuelEfficiencyKmPerL,
        int odometerKm,
        String overallHealthStatus, // NORMAL, MONITOR, SERVICE_REQUIRED, CRITICAL
        String dataSource,          // "Demo Telemetry (OBD-II Simulator)", "CAN Bus Port", "Manual Inspection"
        LocalDateTime lastUpdated) {
}
