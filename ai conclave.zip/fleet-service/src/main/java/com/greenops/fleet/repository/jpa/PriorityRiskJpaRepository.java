package com.greenops.fleet.repository.jpa;

import com.greenops.fleet.entity.PriorityRiskItemEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PriorityRiskJpaRepository extends JpaRepository<PriorityRiskItemEntity, Long> {
    List<PriorityRiskItemEntity> findByPriorityIgnoreCaseOrderByRiskScoreDesc(String priority);
    List<PriorityRiskItemEntity> findByVehicleIdOrderByRiskScoreDesc(Long vehicleId);
    void deleteByVehicleId(Long vehicleId);
}
