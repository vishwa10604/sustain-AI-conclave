package com.greenops.fleet.repository.jpa;

import com.greenops.fleet.entity.VehicleHealthEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VehicleHealthJpaRepository extends JpaRepository<VehicleHealthEntity, Long> {
    Optional<VehicleHealthEntity> findByVehicleId(Long vehicleId);
    void deleteByVehicleId(Long vehicleId);
}
