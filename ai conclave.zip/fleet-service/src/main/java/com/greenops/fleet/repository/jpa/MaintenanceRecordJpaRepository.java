package com.greenops.fleet.repository.jpa;

import com.greenops.fleet.entity.MaintenanceRecordEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MaintenanceRecordJpaRepository extends JpaRepository<MaintenanceRecordEntity, Long> {
    List<MaintenanceRecordEntity> findByVehicleIdOrderByServiceDateDesc(Long vehicleId);
    void deleteByVehicleId(Long vehicleId);
}
