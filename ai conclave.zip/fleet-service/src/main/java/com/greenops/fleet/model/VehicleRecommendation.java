package com.greenops.fleet.model;

import java.util.List;

public record VehicleRecommendation(
        Long vehicleId,
        String registrationNumber,
        String modelName,
        String category,
        String fuelType,
        double estimatedPrice,
        double efficiencyValue,
        String efficiencyUnit,
        String safetyRating,
        double avgAnnualMaintenanceCost,
        int matchScorePercent,
        List<String> advantages,
        List<String> disadvantages,
        String matchJustification,
        List<String> unavailableDataItems) {
}
