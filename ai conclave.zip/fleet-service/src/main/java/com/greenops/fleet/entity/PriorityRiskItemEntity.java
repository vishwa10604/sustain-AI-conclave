package com.greenops.fleet.entity;

import com.greenops.fleet.model.PriorityRiskItem;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "priority_risk_items")
public class PriorityRiskItemEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long vehicleId;
    private String vehicleModel;
    private String registrationNumber;
    private String riskCategory;
    private String priority; // HIGH, MEDIUM, LOW

    @Column(length = 500)
    private String detectedIssue;

    private String measuredValue;
    private String expectedRange;
    private int riskScore;

    @Column(length = 1000)
    private String reason;

    @Column(length = 1000)
    private String recommendedAction;

    private LocalDate detectedDate;
    private LocalDateTime lastUpdated;
    private String status; // Open, In Progress, Resolved

    public PriorityRiskItemEntity() {}

    public PriorityRiskItemEntity(Long id, Long vehicleId, String vehicleModel, String registrationNumber,
                                  String riskCategory, String priority, String detectedIssue,
                                  String measuredValue, String expectedRange, int riskScore,
                                  String reason, String recommendedAction, LocalDate detectedDate,
                                  LocalDateTime lastUpdated, String status) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.vehicleModel = vehicleModel;
        this.registrationNumber = registrationNumber;
        this.riskCategory = riskCategory;
        this.priority = priority;
        this.detectedIssue = detectedIssue;
        this.measuredValue = measuredValue;
        this.expectedRange = expectedRange;
        this.riskScore = riskScore;
        this.reason = reason;
        this.recommendedAction = recommendedAction;
        this.detectedDate = detectedDate;
        this.lastUpdated = lastUpdated;
        this.status = status;
    }

    public static PriorityRiskItemEntity fromModel(PriorityRiskItem r) {
        return new PriorityRiskItemEntity(
                r.id(), r.vehicleId(), r.vehicleModel(), r.registrationNumber(),
                r.riskCategory(), r.priority(), r.detectedIssue(),
                r.measuredValue(), r.expectedRange(), r.riskScore(),
                r.reason(), r.recommendedAction(), r.detectedDate(),
                r.lastUpdated(), r.status()
        );
    }

    public PriorityRiskItem toModel() {
        return new PriorityRiskItem(
                id, vehicleId, vehicleModel, registrationNumber,
                riskCategory, priority, detectedIssue,
                measuredValue, expectedRange, riskScore,
                reason, recommendedAction, detectedDate,
                lastUpdated, status
        );
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public String getVehicleModel() { return vehicleModel; }
    public void setVehicleModel(String vehicleModel) { this.vehicleModel = vehicleModel; }
    public String getRegistrationNumber() { return registrationNumber; }
    public void setRegistrationNumber(String registrationNumber) { this.registrationNumber = registrationNumber; }
    public String getRiskCategory() { return riskCategory; }
    public void setRiskCategory(String riskCategory) { this.riskCategory = riskCategory; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public String getDetectedIssue() { return detectedIssue; }
    public void setDetectedIssue(String detectedIssue) { this.detectedIssue = detectedIssue; }
    public String getMeasuredValue() { return measuredValue; }
    public void setMeasuredValue(String measuredValue) { this.measuredValue = measuredValue; }
    public String getExpectedRange() { return expectedRange; }
    public void setExpectedRange(String expectedRange) { this.expectedRange = expectedRange; }
    public int getRiskScore() { return riskScore; }
    public void setRiskScore(int riskScore) { this.riskScore = riskScore; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public String getRecommendedAction() { return recommendedAction; }
    public void setRecommendedAction(String recommendedAction) { this.recommendedAction = recommendedAction; }
    public LocalDate getDetectedDate() { return detectedDate; }
    public void setDetectedDate(LocalDate detectedDate) { this.detectedDate = detectedDate; }
    public LocalDateTime getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDateTime lastUpdated) { this.lastUpdated = lastUpdated; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
