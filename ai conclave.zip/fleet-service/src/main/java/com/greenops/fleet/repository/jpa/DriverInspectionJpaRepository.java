package com.greenops.fleet.repository.jpa;

import com.greenops.fleet.entity.DriverInspectionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DriverInspectionJpaRepository extends JpaRepository<DriverInspectionEntity, Long> {
    List<DriverInspectionEntity> findAllByOrderByTimestampDesc();
    List<DriverInspectionEntity> findByVehicleIdOrderByTimestampDesc(Long vehicleId);
}
