package com.greenops.fleet.repository.jpa;

import com.greenops.fleet.entity.VehicleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VehicleJpaRepository extends JpaRepository<VehicleEntity, Long> {
    Optional<VehicleEntity> findByRegistrationNumberIgnoreCase(String registrationNumber);
}
