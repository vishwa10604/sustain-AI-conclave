package com.greenops.fleet.model;

import java.time.LocalDate;

public record Vehicle(
        Long id,
        String registrationNumber,
        String type,
        String fuelType,
        int year,
        int odometerKm,
        LocalDate lastServiceDate,
        String modelName,
        double estimatedPrice,
        String safetyRating,
        double fuelEfficiencyKmPerL
) {
    public Vehicle(Long id, String registrationNumber, String type, String fuelType,
                   int year, int odometerKm, LocalDate lastServiceDate) {
        this(id, registrationNumber, type, fuelType, year, odometerKm, lastServiceDate,
             type + " " + year, 1200000.0, "4-Star NCAP", 14.5);
    }
}

