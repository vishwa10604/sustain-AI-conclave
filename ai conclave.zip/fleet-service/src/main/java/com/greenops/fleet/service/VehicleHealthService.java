package com.greenops.fleet.service;

import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.model.VehicleHealth;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class VehicleHealthService {

    private final FleetRepository repository;

    public VehicleHealthService(FleetRepository repository) {
        this.repository = repository;
    }

    public VehicleHealth getHealth(Long vehicleId) {
        return repository.findHealthByVehicleId(vehicleId)
                .orElseGet(() -> createDefaultHealth(vehicleId));
    }

    public List<VehicleHealth> getAllHealth() {
        return repository.findAllVehicles().stream()
                .map(v -> getHealth(v.id()))
                .toList();
    }

    public VehicleHealth updateHealth(Long vehicleId, VehicleHealth vh) {
        repository.findVehicleById(vehicleId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehicle not found: " + vehicleId));
        VehicleHealth updated = new VehicleHealth(
                vehicleId,
                vh.oilLevelPercent(), vh.oilPressureStatus(), vh.oilCondition(),
                vh.lastOilChange(), vh.nextOilChange(), vh.oilMaintenanceStatus(),
                vh.tirePressureFlPsi(), vh.tirePressureFrPsi(), vh.tirePressureRlPsi(), vh.tirePressureRrPsi(),
                vh.recommendedTirePressurePsi(),
                vh.tireTreadFlMm(), vh.tireTreadFrMm(), vh.tireTreadRlMm(), vh.tireTreadRrMm(),
                vh.tireInspectionStatus(),
                vh.coolantTempCelsius(), vh.batteryHealthPercent(), vh.batteryVoltage(),
                vh.brakePadFrontPercent(), vh.brakePadRearPercent(), vh.brakeFluidStatus(),
                vh.diagnosticTroubleCodes(), vh.fuelEfficiencyKmPerL(), vh.odometerKm(),
                vh.overallHealthStatus(), vh.dataSource(), LocalDateTime.now()
        );
        return repository.saveHealth(updated);
    }

    private VehicleHealth createDefaultHealth(Long vehicleId) {
        Vehicle v = repository.findVehicleById(vehicleId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehicle not found: " + vehicleId));

        return new VehicleHealth(
                vehicleId,
                75.0, "NORMAL", "GOOD", v.lastServiceDate(), v.lastServiceDate() != null ? v.lastServiceDate().plusDays(180) : null, "NORMAL",
                32.0, 32.0, 32.0, 32.0, 32.0, 5.5, 5.5, 5.5, 5.5, "NORMAL",
                90.0, 95.0, 12.6, 60.0, 65.0, "NORMAL",
                List.of(), v.fuelEfficiencyKmPerL(), v.odometerKm(), "NORMAL",
                "Default Initialized Telemetry (Demo)", LocalDateTime.now()
        );
    }
}
