package com.greenops.fleet.controller;

import com.greenops.fleet.config.DataSeeder;
import com.greenops.fleet.repository.FleetRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/database")
@CrossOrigin(origins = "*")
@Tag(name = "Database Management", description = "Endpoints for inspecting connected relational database, table statistics, and health")
public class DatabaseController {

    private final FleetRepository repository;
    private final DataSeeder dataSeeder;

    public DatabaseController(FleetRepository repository, DataSeeder dataSeeder) {
        this.repository = repository;
        this.dataSeeder = dataSeeder;
    }

    @GetMapping("/status")
    @Operation(summary = "Get database status and connection metrics")
    public Map<String, Object> getStatus() {
        return repository.getDatabaseStatistics();
    }

    @GetMapping("/tables")
    @Operation(summary = "Get summary of all database tables and row counts")
    public Map<String, Object> getTables() {
        return repository.getDatabaseStatistics();
    }

    @GetMapping("/table/{tableName}")
    @Operation(summary = "Preview records from a specific database table")
    public List<?> getTablePreview(@PathVariable String tableName) {
        return switch (tableName.toLowerCase()) {
            case "vehicles" -> repository.findAllVehicles();
            case "maintenance_records" -> repository.findAllRecords();
            case "priority_risk_items" -> repository.findAllRisks();
            case "customer_reviews" -> repository.findAllReviews();
            case "smart_notifications" -> repository.findAllNotifications();
            case "user_accounts" -> repository.findAllUsers();
            case "driver_inspections" -> repository.findAllInspections();
            default -> List.of();
        };
    }

    @PostMapping("/reset")
    @Operation(summary = "Reset database and re-seed demo fleet dataset")
    public Map<String, Object> resetDatabase() {
        dataSeeder.run();
        return Map.of("message", "Database re-seeded successfully", "stats", repository.getDatabaseStatistics());
    }
}
