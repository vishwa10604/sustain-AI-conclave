package com.greenops.fleet.config;

import com.greenops.fleet.model.*;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

    private final FleetRepository repo;

    public DataSeeder(FleetRepository repo) {
        this.repo = repo;
    }

    @Override
    public void run(String... args) {
        if (!repo.findAllVehicles().isEmpty()) {
            return;
        }

        LocalDate today = LocalDate.now();
        LocalDateTime now = LocalDateTime.now();

        // 1. Vehicles with Specifications
        Vehicle v1 = repo.saveVehicle(new Vehicle(null, "TN-38-AB-1234", "Truck", "Diesel", 2016, 165000,
                today.minusDays(210), "GreenOps Hauler Pro 16T", 2800000, "3-Star NCAP", 6.8));
        Vehicle v2 = repo.saveVehicle(new Vehicle(null, "TN-37-CD-5678", "Van", "Diesel", 2020, 62000,
                today.minusDays(45), "EcoDelivery Van 2.0", 1650000, "4-Star NCAP", 14.2));
        Vehicle v3 = repo.saveVehicle(new Vehicle(null, "TN-38-EF-9012", "Bus", "Diesel", 2018, 128000,
                today.minusDays(100), "CityShuttle 36-Seater", 3500000, "4-Star NCAP", 4.9));
        Vehicle v4 = repo.saveVehicle(new Vehicle(null, "TN-66-GH-3456", "Electric Car", "Electric", 2023, 18000,
                today.minusDays(20), "VoltStream Sedan EV", 2200000, "5-Star NCAP", 6.8));
        Vehicle v5 = repo.saveVehicle(new Vehicle(null, "TN-37-JK-7890", "Pickup", "Petrol", 2013, 190000,
                today.minusDays(130), "TrailMaster Utility 4x4", 1150000, "3-Star NCAP", 9.5));

        // 2. Maintenance History
        repo.saveRecord(new MaintenanceRecord(null, v1.id(), today.minusDays(210), "ROUTINE_SERVICE", "Oil and filter change", 6500));
        repo.saveRecord(new MaintenanceRecord(null, v1.id(), today.minusDays(120), "BREAKDOWN_REPAIR", "Clutch failure", 18000));
        repo.saveRecord(new MaintenanceRecord(null, v1.id(), today.minusDays(40), "BREAKDOWN_REPAIR", "Radiator leak", 9500));

        repo.saveRecord(new MaintenanceRecord(null, v2.id(), today.minusDays(45), "ROUTINE_SERVICE", "Full service", 5000));

        repo.saveRecord(new MaintenanceRecord(null, v3.id(), today.minusDays(100), "ROUTINE_SERVICE", "Brake inspection", 7200));
        repo.saveRecord(new MaintenanceRecord(null, v3.id(), today.minusDays(60), "BREAKDOWN_REPAIR", "Alternator replacement", 12000));

        repo.saveRecord(new MaintenanceRecord(null, v4.id(), today.minusDays(20), "ROUTINE_SERVICE", "Battery health check", 2000));

        repo.saveRecord(new MaintenanceRecord(null, v5.id(), today.minusDays(130), "ROUTINE_SERVICE", "Engine tune-up", 6000));
        repo.saveRecord(new MaintenanceRecord(null, v5.id(), today.minusDays(30), "BREAKDOWN_REPAIR", "Suspension repair", 8500));

        // 3. Vehicle Health & Telemetry Readings
        repo.saveHealth(new VehicleHealth(
                v1.id(), 42.0, "WARNING", "DEGRADED", today.minusDays(210), today.minusDays(30), "OVERDUE",
                25.0, 31.0, 24.5, 31.5, 32.0, 2.8, 4.5, 2.5, 4.6, "CRITICAL",
                104.0, 74.0, 12.1, 18.0, 35.0, "SERVICE_REQUIRED",
                List.of("P0300", "P0171"), 6.8, 165000, "CRITICAL", "OBD-II CAN Telemetry (Demo)", now
        ));

        repo.saveHealth(new VehicleHealth(
                v2.id(), 88.0, "NORMAL", "GOOD", today.minusDays(45), today.plusDays(135), "NORMAL",
                32.0, 31.5, 32.2, 32.0, 32.0, 6.2, 6.0, 5.8, 5.9, "NORMAL",
                88.0, 91.0, 12.6, 75.0, 80.0, "NORMAL",
                List.of(), 14.2, 62000, "NORMAL", "OBD-II CAN Telemetry (Demo)", now
        ));

        repo.saveHealth(new VehicleHealth(
                v3.id(), 72.0, "NORMAL", "GOOD", today.minusDays(100), today.plusDays(80), "NORMAL",
                34.0, 34.0, 33.5, 33.8, 35.0, 4.8, 4.9, 4.2, 4.5, "MONITOR",
                97.0, 82.0, 24.2, 42.0, 50.0, "NORMAL",
                List.of("P0420"), 4.9, 128000, "MONITOR", "OBD-II CAN Telemetry (Demo)", now
        ));

        repo.saveHealth(new VehicleHealth(
                v4.id(), null, "NORMAL", "GOOD", null, today.plusDays(345), "NORMAL",
                36.0, 36.2, 36.0, 35.8, 36.0, 7.5, 7.4, 7.6, 7.5, "NORMAL",
                32.0, 98.0, 395.0, 88.0, 92.0, "NORMAL",
                List.of(), 6.8, 18000, "NORMAL", "BMS Telemetry Interface (Demo)", now
        ));

        repo.saveHealth(new VehicleHealth(
                v5.id(), 55.0, "NORMAL", "DEGRADED", today.minusDays(130), today.plusDays(50), "DUE_SOON",
                29.0, 31.0, 21.5, 30.5, 32.0, 3.2, 4.0, 2.9, 3.8, "CRITICAL",
                91.0, 68.0, 11.9, 30.0, 38.0, "NORMAL",
                List.of("P0420", "P0442"), 9.5, 190000, "SERVICE_REQUIRED", "OBD-II CAN Telemetry (Demo)", now
        ));

        // 4. Priority Risk Items
        // Table A: High-Priority Risks
        repo.saveRisk(new PriorityRiskItem(null, v1.id(), v1.modelName(), v1.registrationNumber(),
                "BRAKING_SAFETY", "HIGH", "Severe Brake Pad Wear (Front)", "18% thickness",
                "> 40% recommended", 88, "Brake pads worn past 25% safety margin; risk of metal-to-metal scoring and loss of stopping distance",
                "Take vehicle off route immediately and replace front brake pads & rotors", today.minusDays(3), now, "Open"));

        repo.saveRisk(new PriorityRiskItem(null, v1.id(), v1.modelName(), v1.registrationNumber(),
                "POWERTRAIN", "HIGH", "Active Diagnostic Trouble Code P0300 (Random Cylinder Misfire)", "P0300 Active",
                "No fault codes", 85, "Unburned fuel entering catalytic converter; potential risk of catastrophic cylinder damage",
                "Execute diagnostic pin-point test on ignition coils and fuel rail pressure", today.minusDays(5), now, "In Progress"));

        repo.saveRisk(new PriorityRiskItem(null, v5.id(), v5.modelName(), v5.registrationNumber(),
                "TIRE_PRESSURE", "HIGH", "Critical Tire Underinflation (Rear-Left)", "21.5 PSI",
                "32.0 - 34.0 PSI", 78, "Pressure is 33% below manufacturer threshold; severe blowout and rim damage risk under load",
                "Inspect rear tire for bead leak or foreign object, replace or inflate to 32 PSI", today.minusDays(1), now, "Open"));

        // Table B: Medium-Priority Risks
        repo.saveRisk(new PriorityRiskItem(null, v3.id(), v3.modelName(), v3.registrationNumber(),
                "FLUID_SYSTEMS", "MEDIUM", "Engine Coolant Operating Temperature Elevation", "97.0°C",
                "82.0 - 92.0°C", 54, "Operating near maximum threshold under standard driving cycle; indicates potential radiator clogging or sticky thermostat",
                "Perform cooling system pressure flush and verify radiator fan duty cycle", today.minusDays(6), now, "Open"));

        repo.saveRisk(new PriorityRiskItem(null, v5.id(), v5.modelName(), v5.registrationNumber(),
                "ELECTRICAL", "MEDIUM", "12V Battery Under-Voltage & Cranking Decay", "11.9 V",
                "12.4 - 12.8 V", 46, "Battery rest voltage indicates sulfation; potential failure to start in cold conditions",
                "Perform digital conductance battery load test; replace cell if degraded", today.minusDays(8), now, "In Progress"));

        repo.saveRisk(new PriorityRiskItem(null, v1.id(), v1.modelName(), v1.registrationNumber(),
                "SCHEDULED_SERVICE", "MEDIUM", "Routine Service Overdue (>180 Days)", "210 days ago",
                "<= 180 days", 58, "Lubricant breakdown and filter soot accumulation degrade combustion efficiency",
                "Book comprehensive vehicle service within 7 business days", today.minusDays(30), now, "Open"));

        // Table C: Low-Priority Risks
        repo.saveRisk(new PriorityRiskItem(null, v2.id(), v2.modelName(), v2.registrationNumber(),
                "TIRE_PRESSURE", "LOW", "Minor Tire Pressure Variance (Front-Right)", "31.5 PSI",
                "32.0 PSI", 18, "Slight pressure dip attributable to ambient temperature drop",
                "Check and equalize tire pressures during scheduled weekly inspection", today.minusDays(2), now, "Resolved"));

        repo.saveRisk(new PriorityRiskItem(null, v4.id(), v4.modelName(), v4.registrationNumber(),
                "SCHEDULED_SERVICE", "LOW", "Cabin HEPA Filter Approaching Service Milestone", "18,000 km",
                "20,000 km", 12, "Routine filter replacement reminder for climate control efficiency",
                "Plan filter change at the next scheduled 20,000 km checkup", today.minusDays(10), now, "Open"));

        repo.saveRisk(new PriorityRiskItem(null, v3.id(), v3.modelName(), v3.registrationNumber(),
                "FLUID_SYSTEMS", "LOW", "Washer Fluid Reservoir Low", "25% Level",
                "> 50% Level", 10, "Non-critical fluid warning",
                "Top off windshield washer fluid reservoir", today.minusDays(4), now, "Resolved"));

        // 5. Customer Reviews
        repo.saveReview(new CustomerReview(null, v1.id(), "Ramesh Kumar (Fleet Logistics Mgr)", 4,
                "Heavy-duty workhorse but needs strict maintenance schedule",
                "The Hauler Pro handles 14-tonne payloads effortlessly across hills. However, the clutch wears down quickly if loaded above capacity. Oil changes must never be skipped.",
                today.minusDays(45), "POSITIVE", List.of("Clutch wear", "Oil intervals"),
                List.of("Towing capacity", "Torque", "Chassis durability"), true, false, null));

        repo.saveReview(new CustomerReview(null, v1.id(), "Deepak Verma", 2,
                "Frequent breakdown repairs and cooling issues",
                "Had clutch failure twice and a radiator leak within 6 months. High maintenance expenditure overall.",
                today.minusDays(35), "NEGATIVE", List.of("Radiator leak", "Clutch failure", "Maintenance cost"),
                List.of("Engine power"), true, false, null));

        repo.saveReview(new CustomerReview(null, v2.id(), "Karthik Subramanian", 5,
                "Outstanding reliability for daily courier deliveries",
                "Our EcoDelivery Van has reached 62,000 km with zero breakdowns. Fuel economy consistently hits 14.5 km/L in urban traffic. Extremely dependable.",
                today.minusDays(25), "POSITIVE", List.of(),
                List.of("Reliability", "Fuel economy", "Low running cost", "Driver comfort"), true, false, null));

        repo.saveReview(new CustomerReview(null, v3.id(), "Senthil Nathan (Transport Operator)", 3,
                "Spacious bus but alternator needed early replacement",
                "Passenger comfort is great and air conditioning is strong. Alternator had to be replaced at 120k km, which was unexpected. Brake pads wear moderately fast.",
                today.minusDays(55), "NEUTRAL", List.of("Alternator replacement", "Brake wear"),
                List.of("Passenger comfort", "AC performance"), true, false, null));

        repo.saveReview(new CustomerReview(null, v4.id(), "Ananya Balaji", 5,
                "Exceptional electric sedan - virtually zero maintenance",
                "The VoltStream EV is whisper quiet, fast, and has saved us over 70% in monthly fuel and maintenance expenses. Battery health still reads 98% after 18k km.",
                today.minusDays(15), "POSITIVE", List.of(),
                List.of("Energy efficiency", "Zero maintenance", "Battery health", "Safety rating", "Acceleration"), true, false, null));

        repo.saveReview(new CustomerReview(null, v5.id(), "Manoj Selvam", 3,
                "Sturdy off-roader but heavy on fuel consumption",
                "Handles rough construction sites easily. However, petrol mileage is below 9.5 km/L and the 12V battery drains if left parked for over a week.",
                today.minusDays(28), "NEUTRAL", List.of("High fuel consumption", "Battery drainage"),
                List.of("Off-road capability", "Sturdy suspension"), true, false, null));

        // Suspicious Review sample (detected duplicate spam pattern)
        repo.saveReview(new CustomerReview(null, v5.id(), "PromoBot99", 5,
                "BEST TRUCK EVER BUY NOW AT DISCOUNT!!!",
                "BEST TRUCK EVER BUY NOW AT DISCOUNT!!! Contact 99999 for instant deals best price guaranteed.",
                today.minusDays(2), "POSITIVE", List.of(), List.of("Best price"), false, true,
                "Suspicious promotional content with duplicate spam footprint across multiple items"));

        // 6. Smart Notifications
        repo.saveNotification(new SmartNotification(null, v1.id(), v1.registrationNumber(), "CRITICAL",
                "Brake Safety Alert", "Front brake pad thickness is below critical 18% threshold. Immediate inspection required.",
                now.minusHours(4), false, "Open"));

        repo.saveNotification(new SmartNotification(null, v1.id(), v1.registrationNumber(), "CRITICAL",
                "Engine Diagnostic Fault P0300", "Random cylinder misfire detected via OBD-II CAN bus. Catalytic converter damage risk.",
                now.minusHours(8), false, "Open"));

        repo.saveNotification(new SmartNotification(null, v5.id(), v5.modelName(), "WARNING",
                "Tire Pressure Warning (Rear-Left)", "Tire pressure is 21.5 PSI (recommended 32.0 PSI). Potential bead leak.",
                now.minusHours(14), true, "Open"));

        repo.saveNotification(new SmartNotification(null, v3.id(), v3.registrationNumber(), "WARNING",
                "Elevated Coolant Temperature", "Operating temperature peaked at 97.0°C during peak load route.",
                now.minusDays(1), true, "Open"));

        repo.saveNotification(new SmartNotification(null, v4.id(), v4.registrationNumber(), "INFO",
                "Battery Health Verified", "High-voltage traction battery cell balance verified with 98% state-of-health.",
                now.minusDays(2), true, "Resolved"));

        // 7. Role-Based User Accounts (Driver & Vehicle Owner)
        repo.saveUser(new UserAccount(
                "usr-owner-01",
                "owner@greenoops.com",
                "S. Harikumaran (Fleet Owner)",
                "Owner@123",
                "VEHICLE_OWNER",
                true,
                "RC-TN-GO-77821 (Certified Fleet Owner)",
                "ALL_FLEET",
                null
        ));

        repo.saveUser(new UserAccount(
                "usr-driver-01",
                "driver@greenoops.com",
                "Ramesh Kumar (Senior Driver)",
                "Driver@123",
                "DRIVER",
                true,
                "DL-TN-38-2018-99214 (Commercial HMV License)",
                v1.registrationNumber(),
                v1.id()
        ));

        // 8. Pre-Trip Driver Inspection Logs
        repo.saveInspection(new DriverInspection(
                null, v1.id(), "Ramesh Kumar", v1.registrationNumber(),
                false, // Tire pressure visual warning
                true,  // Oil checked
                false, // Brakes feel soft/critical wear
                true,  // Lights ok
                165000,
                "Front brakes require immediate workshop inspection; pedal feels spongy. Rear-left tire visual appears low.",
                now.minusHours(3),
                "ACTION_REQUIRED"
        ));
    }
}
