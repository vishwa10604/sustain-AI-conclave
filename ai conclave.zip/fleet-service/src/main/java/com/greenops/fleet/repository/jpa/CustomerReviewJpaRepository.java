package com.greenops.fleet.repository.jpa;

import com.greenops.fleet.entity.CustomerReviewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerReviewJpaRepository extends JpaRepository<CustomerReviewEntity, Long> {
    List<CustomerReviewEntity> findByVehicleIdOrderByReviewDateDesc(Long vehicleId);
    void deleteByVehicleId(Long vehicleId);
}
