package com.greenops.fleet.service;

import com.greenops.fleet.model.MaintenanceRecord;
import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

@Service
public class VehicleService {

    private final FleetRepository repository;

    public VehicleService(FleetRepository repository) {
        this.repository = repository;
    }

    public List<Vehicle> getAll() {
        return repository.findAllVehicles();
    }

    public Vehicle getById(Long id) {
        return repository.findVehicleById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Vehicle not found: " + id));
    }

    public Vehicle create(Vehicle v) {
        validate(v);
        return repository.saveVehicle(new Vehicle(null, v.registrationNumber(), v.type(),
                v.fuelType(), v.year(), v.odometerKm(), v.lastServiceDate()));
    }

    public Vehicle update(Long id, Vehicle v) {
        getById(id);
        validate(v);
        return repository.saveVehicle(new Vehicle(id, v.registrationNumber(), v.type(),
                v.fuelType(), v.year(), v.odometerKm(), v.lastServiceDate()));
    }

    public void delete(Long id) {
        if (!repository.deleteVehicle(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehicle not found: " + id);
        }
    }

    public List<MaintenanceRecord> getMaintenance(Long vehicleId) {
        getById(vehicleId);
        return repository.findRecordsByVehicleId(vehicleId);
    }

    public List<MaintenanceRecord> getAllMaintenance() {
        return repository.findAllRecords();
    }

    public MaintenanceRecord addMaintenance(Long vehicleId, MaintenanceRecord r) {
        Vehicle vehicle = getById(vehicleId);
        if (r.type() == null || r.type().isBlank() || r.serviceDate() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "type and serviceDate are required");
        }
        if (r.serviceDate().isAfter(LocalDate.now())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "serviceDate cannot be in the future");
        }
        if (r.cost() < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "cost cannot be negative");
        }
        MaintenanceRecord saved = repository.saveRecord(new MaintenanceRecord(
                null, vehicleId, r.serviceDate(), r.type(), r.description(), r.cost()));

        // A routine service resets the vehicle's last service date
        if ("ROUTINE_SERVICE".equalsIgnoreCase(r.type())
                && (vehicle.lastServiceDate() == null
                    || r.serviceDate().isAfter(vehicle.lastServiceDate()))) {
            repository.saveVehicle(new Vehicle(vehicle.id(), vehicle.registrationNumber(),
                    vehicle.type(), vehicle.fuelType(), vehicle.year(),
                    vehicle.odometerKm(), r.serviceDate()));
        }
        return saved;
    }

    private void validate(Vehicle v) {
        if (v.registrationNumber() == null || v.registrationNumber().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "registrationNumber is required");
        }
        if (v.odometerKm() < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "odometerKm cannot be negative");
        }
        int maxYear = LocalDate.now().getYear() + 1;
        if (v.year() < 1980 || v.year() > maxYear) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "year must be between 1980 and " + maxYear);
        }
        if (v.lastServiceDate() != null && v.lastServiceDate().isAfter(LocalDate.now())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "lastServiceDate cannot be in the future");
        }
    }
}
