package com.greenops.fleet.controller;

import com.greenops.fleet.service.GreenDrivingService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/green-driving")
@CrossOrigin(origins = "*")
public class GreenDrivingController {

    private final GreenDrivingService greenDrivingService;

    public GreenDrivingController(GreenDrivingService greenDrivingService) {
        this.greenDrivingService = greenDrivingService;
    }

    @GetMapping
    public Map<String, Object> getGreenAnalytics() {
        return greenDrivingService.getGreenFleetAnalytics();
    }
}
