package com.greenops.fleet.service;

import com.greenops.fleet.model.MaintenanceRecord;
import com.greenops.fleet.model.RiskReport;
import com.greenops.fleet.model.Vehicle;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Rule-based maintenance risk score (0-100).
 *
 * Rules:
 *  - Days since last service : >180 = +30, >90 = +15
 *  - Odometer (km)           : >150000 = +20, >80000 = +10
 *  - Vehicle age (years)     : >8 = +15, >5 = +8
 *  - Breakdown repairs in last 180 days: +10 each, max +25
 *
 * Level: 0-29 LOW, 30-59 MEDIUM, 60-100 HIGH
 */
@Service
public class MaintenanceRiskService {

    private final VehicleService vehicleService;

    public MaintenanceRiskService(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    public RiskReport assess(Long vehicleId) {
        Vehicle vehicle = vehicleService.getById(vehicleId);
        List<MaintenanceRecord> records = vehicleService.getMaintenance(vehicleId);
        return calculate(vehicle, records, LocalDate.now());
    }

    public List<RiskReport> assessAll() {
        LocalDate today = LocalDate.now();
        return vehicleService.getAll().stream()
                .map(v -> calculate(v, vehicleService.getMaintenance(v.id()), today))
                .sorted(Comparator.comparingInt(RiskReport::riskScore).reversed())
                .toList();
    }

    RiskReport calculate(Vehicle v, List<MaintenanceRecord> records, LocalDate today) {
        int score = 0;
        List<String> reasons = new ArrayList<>();

        // Rule 1: time since last service
        if (v.lastServiceDate() == null) {
            score += 30;
            reasons.add("No service date on record (+30)");
        } else {
            long days = ChronoUnit.DAYS.between(v.lastServiceDate(), today);
            if (days > 180) {
                score += 30;
                reasons.add("Last service " + days + " days ago (+30)");
            } else if (days > 90) {
                score += 15;
                reasons.add("Last service " + days + " days ago (+15)");
            }
        }

        // Rule 2: odometer
        if (v.odometerKm() > 150_000) {
            score += 20;
            reasons.add("High mileage: " + v.odometerKm() + " km (+20)");
        } else if (v.odometerKm() > 80_000) {
            score += 10;
            reasons.add("Moderate mileage: " + v.odometerKm() + " km (+10)");
        }

        // Rule 3: vehicle age
        int age = today.getYear() - v.year();
        if (age > 8) {
            score += 15;
            reasons.add("Vehicle age " + age + " years (+15)");
        } else if (age > 5) {
            score += 8;
            reasons.add("Vehicle age " + age + " years (+8)");
        }

        // Rule 4: recent breakdowns
        LocalDate cutoff = today.minusDays(180);
        long breakdowns = (records == null) ? 0 : records.stream()
                .filter(r -> "BREAKDOWN_REPAIR".equalsIgnoreCase(r.type()))
                .filter(r -> r.serviceDate() != null && !r.serviceDate().isBefore(cutoff) && !r.serviceDate().isAfter(today))
                .count();
        if (breakdowns > 0) {
            int points = (int) Math.min(breakdowns * 10, 25);
            score += points;
            reasons.add(breakdowns + " breakdown repair(s) in last 180 days (+" + points + ")");
        }

        score = Math.max(0, Math.min(score, 100));

        String level;
        String recommendation;
        if (score >= 60) {
            level = "HIGH";
            recommendation = "Schedule maintenance immediately and consider taking the vehicle off route.";
        } else if (score >= 30) {
            level = "MEDIUM";
            recommendation = "Plan a service within the next 2 weeks.";
        } else {
            level = "LOW";
            recommendation = "No action needed. Continue routine monitoring.";
        }

        if (reasons.isEmpty()) {
            reasons.add("No risk factors detected");
        }
        return new RiskReport(v.id(), v.registrationNumber(), score, level, reasons, recommendation);
    }
}
