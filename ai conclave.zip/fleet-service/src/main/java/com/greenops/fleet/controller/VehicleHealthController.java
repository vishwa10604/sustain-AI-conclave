package com.greenops.fleet.controller;

import com.greenops.fleet.model.VehicleHealth;
import com.greenops.fleet.service.VehicleHealthService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/health")
@CrossOrigin(origins = "*")
public class VehicleHealthController {

    private final VehicleHealthService healthService;

    public VehicleHealthController(VehicleHealthService healthService) {
        this.healthService = healthService;
    }

    @GetMapping("/{vehicleId}")
    public VehicleHealth getHealth(@PathVariable Long vehicleId) {
        return healthService.getHealth(vehicleId);
    }

    @GetMapping
    public List<VehicleHealth> getAllHealth() {
        return healthService.getAllHealth();
    }

    @PutMapping("/{vehicleId}")
    public VehicleHealth updateHealth(@PathVariable Long vehicleId, @RequestBody VehicleHealth health) {
        return healthService.updateHealth(vehicleId, health);
    }
}
