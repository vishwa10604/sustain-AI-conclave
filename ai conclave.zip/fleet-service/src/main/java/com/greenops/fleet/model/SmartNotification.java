package com.greenops.fleet.model;

import java.time.LocalDateTime;

public record SmartNotification(
        Long id,
        Long vehicleId,
        String registrationNumber,
        String priority, // CRITICAL, WARNING, INFO
        String title,
        String message,
        LocalDateTime timestamp,
        boolean acknowledged,
        String status // Open, Resolved
) {
    public SmartNotification withAcknowledged(boolean ack) {
        return new SmartNotification(id, vehicleId, registrationNumber, priority, title, message, timestamp, ack, status);
    }

    public SmartNotification withStatus(String newStatus) {
        return new SmartNotification(id, vehicleId, registrationNumber, priority, title, message, timestamp, acknowledged, newStatus);
    }
}
