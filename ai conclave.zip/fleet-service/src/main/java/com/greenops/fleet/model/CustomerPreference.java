package com.greenops.fleet.model;

import java.util.List;

public record CustomerPreference(
        Double minBudget,
        Double maxBudget,
        String usage,            // City, Highway, Family, Commercial
        String fuelPreference,   // Petrol, Diesel, Hybrid, Electric, No Preference
        Double minEfficiency,    // km/L or km/kWh
        String safetyPriority,   // Standard, High, Maximum
        Double maxMaintenanceBudget,
        String preferredVehicleType // Truck, Van, Bus, Electric Car, Pickup, Any
) {
}
