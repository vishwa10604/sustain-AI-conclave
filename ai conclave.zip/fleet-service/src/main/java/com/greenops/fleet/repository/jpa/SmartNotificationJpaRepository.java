package com.greenops.fleet.repository.jpa;

import com.greenops.fleet.entity.SmartNotificationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SmartNotificationJpaRepository extends JpaRepository<SmartNotificationEntity, Long> {
    List<SmartNotificationEntity> findAllByOrderByTimestampDesc();
    void deleteByVehicleId(Long vehicleId);
}
