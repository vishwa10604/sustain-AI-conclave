package com.greenops.fleet.service;

import com.greenops.fleet.model.*;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class VehicleHealthReportService {

    private final FleetRepository repository;
    private final MaintenanceRiskService riskService;
    private final VehicleHealthService healthService;

    public VehicleHealthReportService(FleetRepository repository,
                                      MaintenanceRiskService riskService,
                                      VehicleHealthService healthService) {
        this.repository = repository;
        this.riskService = riskService;
        this.healthService = healthService;
    }

    public Map<String, Object> generateComprehensiveReport(Long vehicleId) {
        Vehicle vehicle = repository.findVehicleById(vehicleId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehicle not found: " + vehicleId));

        RiskReport riskReport = riskService.assess(vehicleId);
        VehicleHealth health = healthService.getHealth(vehicleId);
        List<MaintenanceRecord> maintenance = repository.findRecordsByVehicleId(vehicleId);
        List<PriorityRiskItem> priorityRisks = repository.findRisksByVehicleId(vehicleId);

        List<PriorityRiskItem> highRisks = priorityRisks.stream().filter(r -> "HIGH".equalsIgnoreCase(r.priority())).toList();
        List<PriorityRiskItem> mediumRisks = priorityRisks.stream().filter(r -> "MEDIUM".equalsIgnoreCase(r.priority())).toList();
        List<PriorityRiskItem> lowRisks = priorityRisks.stream().filter(r -> "LOW".equalsIgnoreCase(r.priority())).toList();

        String healthSummary;
        if (riskReport.riskScore() >= 60 || (health != null && "CRITICAL".equalsIgnoreCase(health.overallHealthStatus()))) {
            healthSummary = "CRITICAL ALERT: Immediate mechanical intervention required. Safety-critical issues detected in braking or powertrain systems.";
        } else if (riskReport.riskScore() >= 30 || (health != null && "SERVICE_REQUIRED".equalsIgnoreCase(health.overallHealthStatus()))) {
            healthSummary = "ADVISORY: Vehicle exhibits moderate wear and scheduled servicing requirements. Schedule workshop inspection within 14 days.";
        } else {
            healthSummary = "OPTIMAL: Vehicle operating within standard operational parameters. Routine preventive maintenance schedule active.";
        }

        Map<String, Object> report = new HashMap<>();
        report.put("reportId", "GO-VHR-" + vehicle.id() + "-" + System.currentTimeMillis());
        report.put("generatedAt", LocalDateTime.now());
        report.put("vehicle", vehicle);
        report.put("healthSummary", healthSummary);
        report.put("riskAssessment", riskReport);
        report.put("telemetry", health);
        report.put("findings", Map.of(
                "highPriority", highRisks,
                "mediumPriority", mediumRisks,
                "lowPriority", lowRisks
        ));
        report.put("diagnosticCodes", health != null ? health.diagnosticTroubleCodes() : List.of());
        report.put("maintenanceHistory", maintenance);
        report.put("recommendedActions", List.of(
                riskReport.recommendation(),
                "Perform certified brake pad caliper micrometer verification",
                "Ensure tire inflation is balanced to manufacturer cold spec (" + (health != null ? health.recommendedTirePressurePsi() : 32.0) + " PSI)",
                "Clear confirmed diagnostic trouble codes after physical root-cause rectification"
        ));
        report.put("dataLimitations", List.of(
                "Telemetry originates from verified onboard OBD-II diagnostics and vehicle service records.",
                "Real-time sensor telemetry for development represents calibrated simulation data.",
                "This assessment does not replace hands-on statutory technical safety inspections by a certified master technician."
        ));

        return report;
    }
}
