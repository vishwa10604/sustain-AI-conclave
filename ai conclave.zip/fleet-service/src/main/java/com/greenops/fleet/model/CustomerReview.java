package com.greenops.fleet.model;

import java.time.LocalDate;
import java.util.List;

public record CustomerReview(
        Long id,
        Long vehicleId,
        String author,
        int rating,
        String title,
        String comment,
        LocalDate reviewDate,
        String sentiment, // POSITIVE, NEGATIVE, NEUTRAL
        List<String> problemTags,
        List<String> praiseTags,
        boolean verifiedPurchase,
        boolean flaggedSuspicious,
        String suspiciousReason) {
}
