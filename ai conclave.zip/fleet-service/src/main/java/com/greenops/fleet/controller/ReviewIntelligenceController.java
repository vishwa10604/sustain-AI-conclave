package com.greenops.fleet.controller;

import com.greenops.fleet.model.CustomerReview;
import com.greenops.fleet.model.ReviewAnalysis;
import com.greenops.fleet.service.ReviewIntelligenceService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "*")
public class ReviewIntelligenceController {

    private final ReviewIntelligenceService reviewService;

    public ReviewIntelligenceController(ReviewIntelligenceService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping
    public List<CustomerReview> getAllReviews() {
        return reviewService.getAllReviews();
    }

    @GetMapping("/vehicle/{vehicleId}")
    public List<CustomerReview> getReviewsForVehicle(@PathVariable Long vehicleId) {
        return reviewService.getReviewsForVehicle(vehicleId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CustomerReview createReview(@RequestBody CustomerReview review) {
        return reviewService.submitReview(review);
    }

    @GetMapping("/analysis")
    public ReviewAnalysis getAnalysis() {
        return reviewService.analyzeReviews();
    }
}
