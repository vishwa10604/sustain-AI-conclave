package com.greenops.fleet.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI greenOpsOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("GreenOps Smart Fleet & Automotive Risk Microservice API")
                        .description("Microservice architecture featuring vehicle telemetry, priority risk scoring (Tables A/B/C), Spring Data JPA database integration, driver safety sign-offs, customer review intelligence, and Spring AI assistance.")
                        .version("v1.0.0")
                        .contact(new Contact()
                                .name("GreenOps Automotive Engineering")
                                .email("dev@greenoops.com"))
                        .license(new License()
                                .name("Apache 2.0")
                                .url("https://spring.io")));
    }
}
