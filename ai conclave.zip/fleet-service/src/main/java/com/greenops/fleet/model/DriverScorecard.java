package com.greenops.fleet.model;

import java.util.List;

public record DriverScorecard(
        String driverName,
        String assignedVehicle,
        int safetyScore, // 0 - 100
        int efficiencyScore, // 0 - 100
        double harshBrakingPer100Km,
        double overspeedIncidents,
        double idleFuelWastePercent,
        String overallGrade, // "A+ (Master)", "B (Standard)", "C (Needs Training)"
        List<String> drivingBehaviorObservations
) {
}
