package com.greenops.fleet.service;

import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.model.VehicleHealth;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GreenDrivingService {

    private final FleetRepository repository;

    public GreenDrivingService(FleetRepository repository) {
        this.repository = repository;
    }

    public Map<String, Object> getGreenFleetAnalytics() {
        List<Vehicle> vehicles = repository.findAllVehicles();

        List<Map<String, Object>> vehicleImpactList = new ArrayList<>();
        double totalFleetEmissionsGPerKm = 0;
        int countIce = 0;

        for (Vehicle v : vehicles) {
            double efficiency = v.fuelEfficiencyKmPerL();
            double co2GramsPerKm;
            String calcMethod;

            if ("Electric".equalsIgnoreCase(v.fuelType())) {
                co2GramsPerKm = 0.0; // Zero direct tailpipe emissions
                calcMethod = "0 g/km tailpipe (Certified EV). Life-cycle grid intensity approx 82 g/km based on CEA national generation average.";
            } else if ("Diesel".equalsIgnoreCase(v.fuelType())) {
                // 2640 g CO2 / Liter
                co2GramsPerKm = efficiency > 0 ? (2640.0 / efficiency) : 350.0;
                calcMethod = "Calculated as 2,640 g CO2/L divided by rated efficiency (" + efficiency + " km/L) = " + Math.round(co2GramsPerKm) + " g/km.";
                totalFleetEmissionsGPerKm += co2GramsPerKm;
                countIce++;
            } else {
                // Petrol: 2392 g CO2 / Liter
                co2GramsPerKm = efficiency > 0 ? (2392.0 / efficiency) : 250.0;
                calcMethod = "Calculated as 2,392 g CO2/L divided by rated efficiency (" + efficiency + " km/L) = " + Math.round(co2GramsPerKm) + " g/km.";
                totalFleetEmissionsGPerKm += co2GramsPerKm;
                countIce++;
            }

            VehicleHealth health = repository.findHealthByVehicleId(v.id()).orElse(null);
            double ecoScore = 80.0;
            if ("Electric".equalsIgnoreCase(v.fuelType())) {
                ecoScore = 98.0;
            } else {
                if (health != null && health.tireInspectionStatus().equalsIgnoreCase("CRITICAL")) ecoScore -= 12.0;
                if (health != null && health.oilMaintenanceStatus().equalsIgnoreCase("OVERDUE")) ecoScore -= 10.0;
            }

            vehicleImpactList.add(Map.of(
                    "vehicleId", v.id(),
                    "registrationNumber", v.registrationNumber(),
                    "modelName", v.modelName(),
                    "fuelType", v.fuelType(),
                    "efficiency", efficiency,
                    "efficiencyUnit", "Electric".equalsIgnoreCase(v.fuelType()) ? "km/kWh" : "km/L",
                    "co2GramsPerKm", Math.round(co2GramsPerKm * 10.0) / 10.0,
                    "calculationMethodology", calcMethod,
                    "ecoScore", Math.round(ecoScore)
            ));
        }

        double avgIceEmissions = countIce > 0 ? (totalFleetEmissionsGPerKm / countIce) : 0.0;

        List<String> maintenanceEcoTips = List.of(
                "Maintain Manufacturer Recommended Tire Pressure (32-36 PSI): Correct inflation reduces rolling resistance and lowers fuel consumption by 3.2% - 5.0%.",
                "Timely Engine Oil & Air Filter Replacements: Clean lubricants reduce internal combustion drag, improving efficiency by up to 4.5% and reducing particulate emissions.",
                "Oxygen Sensor & Catalytic Converter Diagnostic Monitoring: Resolving active DTCs (such as P0300 or P0420) prevents unburned fuel waste, saving up to 15% in wasted fuel.",
                "Fleet Electrification Transition: Transitioning urban delivery routes to VoltStream EV eliminates 100% of urban tailpipe emissions and cuts operating energy costs by 72%."
        );

        Map<String, Object> evComparison = Map.of(
                "dieselTruckCo2Per1000KmKg", 388.0,
                "petrolPickupCo2Per1000KmKg", 251.0,
                "dieselVanCo2Per1000KmKg", 185.0,
                "evSedanTailpipeCo2Per1000KmKg", 0.0,
                "annualCo2SavingsPerEvTons", 4.2
        );

        Map<String, Object> response = new HashMap<>();
        response.put("vehicles", vehicleImpactList);
        response.put("averageIceFleetEmissionsGPerKm", Math.round(avgIceEmissions * 10.0) / 10.0);
        response.put("maintenanceEcoTips", maintenanceEcoTips);
        response.put("evComparison", evComparison);
        response.put("documentedAssumptions", "CO2 emission factors derived from IPCC Tier 1 Mobile Combustion Guidelines (Diesel: 2,640 g/L, Petrol: 2,392 g/L). Electric calculation assumes 0 g/km direct tailpipe emissions.");

        return response;
    }
}
