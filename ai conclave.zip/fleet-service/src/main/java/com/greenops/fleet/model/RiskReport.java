package com.greenops.fleet.model;

import java.util.List;

public record RiskReport(
        Long vehicleId,
        String registrationNumber,
        int riskScore,
        String riskLevel,
        List<String> reasons,
        String recommendation) {
}
