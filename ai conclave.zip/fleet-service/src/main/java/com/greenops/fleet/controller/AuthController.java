package com.greenops.fleet.controller;

import com.greenops.fleet.model.DriverInspection;
import com.greenops.fleet.model.UserAccount;
import com.greenops.fleet.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/auth/login")
    public Map<String, Object> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");
        return authService.login(email, password);
    }

    @GetMapping("/auth/current")
    public UserAccount getCurrentUser(@RequestHeader(value = "Authorization", required = false) String token) {
        return authService.getCurrentUser(token);
    }

    @PostMapping("/auth/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(@RequestHeader(value = "Authorization", required = false) String token) {
        authService.logout(token);
    }

    @PostMapping("/driver/inspection")
    @ResponseStatus(HttpStatus.CREATED)
    public DriverInspection submitInspection(@RequestBody DriverInspection inspection) {
        return authService.submitInspection(inspection);
    }

    @GetMapping("/driver/inspections")
    public List<DriverInspection> getInspections(@RequestParam(required = false) Long vehicleId) {
        return authService.getInspections(vehicleId);
    }
}
