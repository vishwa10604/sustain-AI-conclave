package com.greenops.fleet.service;

import com.greenops.fleet.model.CustomerPreference;
import com.greenops.fleet.model.MaintenanceRecord;
import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.model.VehicleRecommendation;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class VehicleRecommendationService {

    private final FleetRepository repository;

    public VehicleRecommendationService(FleetRepository repository) {
        this.repository = repository;
    }

    public List<VehicleRecommendation> getRecommendations(CustomerPreference pref) {
        List<Vehicle> vehicles = repository.findAllVehicles();

        return vehicles.stream()
                .map(v -> evaluateVehicle(v, pref))
                .sorted(Comparator.comparingInt(VehicleRecommendation::matchScorePercent).reversed())
                .toList();
    }

    private VehicleRecommendation evaluateVehicle(Vehicle v, CustomerPreference pref) {
        int score = 60; // base score
        List<String> pros = new ArrayList<>();
        List<String> cons = new ArrayList<>();
        List<String> unavailable = new ArrayList<>();

        // 1. Budget Fit
        if (pref.maxBudget() != null && pref.maxBudget() > 0) {
            if (v.estimatedPrice() <= pref.maxBudget()) {
                score += 15;
                pros.add("Comfortably within budget ceiling (₹" + Math.round(v.estimatedPrice()) + ")");
            } else {
                score -= 20;
                cons.add("Exceeds target budget ceiling by ₹" + Math.round(v.estimatedPrice() - pref.maxBudget()));
            }
        }

        // 2. Fuel Type Preference
        if (pref.fuelPreference() != null && !pref.fuelPreference().equalsIgnoreCase("No Preference") && !pref.fuelPreference().isBlank()) {
            if (v.fuelType().equalsIgnoreCase(pref.fuelPreference())) {
                score += 15;
                pros.add("Matches preferred powertrain: " + v.fuelType());
            } else {
                score -= 10;
                cons.add("Alternative fuel architecture (" + v.fuelType() + " vs requested " + pref.fuelPreference() + ")");
            }
        }

        // 3. Intended Usage Fit
        if (pref.usage() != null) {
            String usage = pref.usage().toLowerCase();
            if (usage.contains("commercial") && (v.type().equalsIgnoreCase("Truck") || v.type().equalsIgnoreCase("Van"))) {
                score += 15;
                pros.add("Engineered specifically for heavy commercial cargo/delivery duties");
            } else if (usage.contains("city") && (v.type().equalsIgnoreCase("Electric Car") || v.type().equalsIgnoreCase("Van"))) {
                score += 15;
                pros.add("High agility and optimal energy efficiency for urban traffic");
            } else if (usage.contains("family") && (v.type().equalsIgnoreCase("Electric Car") || v.type().equalsIgnoreCase("Bus"))) {
                score += 10;
                pros.add("Spacious passenger seating and 5-Star occupant safety");
            } else if (usage.contains("highway") && (v.type().equalsIgnoreCase("Truck") || v.type().equalsIgnoreCase("Pickup"))) {
                score += 10;
                pros.add("High torque output and robust chassis for long-haul routes");
            }
        }

        // 4. Efficiency
        if (pref.minEfficiency() != null && pref.minEfficiency() > 0) {
            if (v.fuelEfficiencyKmPerL() >= pref.minEfficiency()) {
                score += 10;
                pros.add("Exceeds minimum target efficiency rating (" + v.fuelEfficiencyKmPerL() + ")");
            } else {
                cons.add("Lower fuel efficiency than requested target (" + v.fuelEfficiencyKmPerL() + " vs " + pref.minEfficiency() + ")");
            }
        }

        // 5. Safety Rating
        if (pref.safetyPriority() != null && pref.safetyPriority().toLowerCase().contains("high") || (pref.safetyPriority() != null && pref.safetyPriority().toLowerCase().contains("max"))) {
            if (v.safetyRating().contains("5-Star")) {
                score += 10;
                pros.add("Top-tier 5-Star NCAP crashworthiness certification");
            } else if (v.safetyRating().contains("4-Star")) {
                score += 5;
                pros.add("Certified 4-Star NCAP safety structure");
            } else {
                cons.add("Standard 3-Star occupant safety rating");
            }
        }

        // Calculate average annual maintenance cost from recorded logs
        List<MaintenanceRecord> records = repository.findRecordsByVehicleId(v.id());
        double totalCost = records.stream().mapToDouble(MaintenanceRecord::cost).sum();
        double avgMaintCost = records.isEmpty() ? 8000.0 : totalCost;

        if (pref.maxMaintenanceBudget() != null && pref.maxMaintenanceBudget() > 0) {
            if (avgMaintCost <= pref.maxMaintenanceBudget()) {
                score += 5;
                pros.add("Historical maintenance expenditure aligns with target limits");
            } else {
                cons.add("Annualized maintenance expenditure (₹" + Math.round(avgMaintCost) + ") exceeds preference");
            }
        }

        // Data limitations disclosure
        unavailable.add("Real-time third-party insurance depreciation index is unavailable");
        unavailable.add("OEM certified resale value estimate requires manual appraisal");

        score = Math.max(15, Math.min(98, score));

        String justification = "Assessed " + v.modelName() + " with a match rating of " + score + "%. "
                + (pros.isEmpty() ? "Meets general transport parameters." : "Primary strengths include " + String.join(", ", pros) + ".");

        String effUnit = v.fuelType().equalsIgnoreCase("Electric") ? "km/kWh" : "km/L";

        return new VehicleRecommendation(
                v.id(), v.registrationNumber(), v.modelName(), v.type(), v.fuelType(),
                v.estimatedPrice(), v.fuelEfficiencyKmPerL(), effUnit, v.safetyRating(),
                avgMaintCost, score, pros, cons, justification, unavailable
        );
    }
}
