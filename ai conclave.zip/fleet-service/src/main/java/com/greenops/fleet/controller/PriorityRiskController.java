package com.greenops.fleet.controller;

import com.greenops.fleet.model.PriorityRiskItem;
import com.greenops.fleet.service.PriorityRiskService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/risks")
@CrossOrigin(origins = "*")
public class PriorityRiskController {

    private final PriorityRiskService priorityRiskService;

    public PriorityRiskController(PriorityRiskService priorityRiskService) {
        this.priorityRiskService = priorityRiskService;
    }

    @GetMapping
    public List<PriorityRiskItem> getAll(@RequestParam(required = false) String priority) {
        if (priority != null && !priority.isBlank()) {
            return priorityRiskService.getByPriority(priority);
        }
        return priorityRiskService.getAll();
    }

    @GetMapping("/tables")
    public Map<String, List<PriorityRiskItem>> getCategorizedTables() {
        return priorityRiskService.getCategorizedTables();
    }

    @GetMapping("/summary")
    public Map<String, Object> getRiskSummary() {
        return priorityRiskService.getRiskSummaryMetrics();
    }

    @GetMapping("/vehicle/{vehicleId}")
    public List<PriorityRiskItem> getByVehicle(@PathVariable Long vehicleId) {
        return priorityRiskService.getByVehicle(vehicleId);
    }

    @PatchMapping("/{id}/status")
    public PriorityRiskItem updateStatus(@PathVariable Long id, @RequestBody Map<String, String> payload) {
        String newStatus = payload.getOrDefault("status", "Open");
        return priorityRiskService.updateStatus(id, newStatus);
    }
}
