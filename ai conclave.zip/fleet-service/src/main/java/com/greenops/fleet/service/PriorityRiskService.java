package com.greenops.fleet.service;

import com.greenops.fleet.model.PriorityRiskItem;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class PriorityRiskService {

    private final FleetRepository repository;

    public PriorityRiskService(FleetRepository repository) {
        this.repository = repository;
    }

    public List<PriorityRiskItem> getAll() {
        return repository.findAllRisks();
    }

    public List<PriorityRiskItem> getByPriority(String priority) {
        return repository.findRisksByPriority(priority);
    }

    public List<PriorityRiskItem> getByVehicle(Long vehicleId) {
        return repository.findRisksByVehicleId(vehicleId);
    }

    public PriorityRiskItem updateStatus(Long riskId, String newStatus) {
        if (!List.of("Open", "In Progress", "Resolved").contains(newStatus)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Status must be 'Open', 'In Progress', or 'Resolved'");
        }
        return repository.updateRiskStatus(riskId, newStatus)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Risk record not found: " + riskId));
    }

    public Map<String, List<PriorityRiskItem>> getCategorizedTables() {
        List<PriorityRiskItem> all = repository.findAllRisks();
        return all.stream().collect(Collectors.groupingBy(PriorityRiskItem::priority));
    }

    public Map<String, Object> getRiskSummaryMetrics() {
        List<PriorityRiskItem> all = repository.findAllRisks();
        long high = all.stream().filter(r -> "HIGH".equalsIgnoreCase(r.priority()) && !"Resolved".equalsIgnoreCase(r.status())).count();
        long medium = all.stream().filter(r -> "MEDIUM".equalsIgnoreCase(r.priority()) && !"Resolved".equalsIgnoreCase(r.status())).count();
        long low = all.stream().filter(r -> "LOW".equalsIgnoreCase(r.priority()) && !"Resolved".equalsIgnoreCase(r.status())).count();
        long openTotal = all.stream().filter(r -> !"Resolved".equalsIgnoreCase(r.status())).count();
        long overdueService = all.stream().filter(r -> "SCHEDULED_SERVICE".equalsIgnoreCase(r.riskCategory()) && !"Resolved".equalsIgnoreCase(r.status())).count();

        return Map.of(
                "totalMonitoredVehicles", repository.findAllVehicles().size(),
                "highPriorityCount", high,
                "mediumPriorityCount", medium,
                "lowPriorityCount", low,
                "requiringInspectionCount", openTotal,
                "overdueMaintenanceCount", overdueService
        );
    }
}
