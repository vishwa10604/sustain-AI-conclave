package com.greenops.fleet.service;

import com.greenops.fleet.model.*;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AiCustomerAssistantService {

    private final FleetRepository repository;
    private final ReviewIntelligenceService reviewService;
    private final RestClient restClient;

    @Value("${spring.ai.openai.api-key:${OPENAI_API_KEY:}}")
    private String apiKey;

    @Value("${spring.ai.openai.base-url:https://api.openai.com/v1}")
    private String baseUrl;

    @Value("${spring.ai.openai.chat.options.model:gpt-4o-mini}")
    private String modelName;

    public AiCustomerAssistantService(FleetRepository repository, ReviewIntelligenceService reviewService) {
        this.repository = repository;
        this.reviewService = reviewService;
        this.restClient = RestClient.builder().build();
    }

    public Map<String, Object> askAssistant(String userPrompt) {
        if (userPrompt == null || userPrompt.isBlank()) {
            return Map.of("response", "Please provide a query regarding our fleet vehicles, maintenance, or reviews.", "grounded", true);
        }

        String promptLower = userPrompt.toLowerCase().trim();

        // 1. If real Spring AI / OpenAI API key is configured, use live LLM with strict grounding prompt
        if (apiKey != null && !apiKey.isBlank() && !apiKey.startsWith("demo")) {
            try {
                String liveResponse = callLiveLlm(userPrompt);
                if (liveResponse != null && !liveResponse.isBlank()) {
                    return Map.of("response", liveResponse, "grounded", true, "engine", "Spring AI (Live LLM: " + modelName + ")");
                }
            } catch (Exception e) {
                // Fall through to deterministic grounded assistant
            }
        }

        // 2. Deterministic, fully grounded Automotive Intelligence Assistant
        return handleGroundedAssistant(promptLower, userPrompt);
    }

    private Map<String, Object> handleGroundedAssistant(String promptLower, String rawPrompt) {
        List<Vehicle> vehicles = repository.findAllVehicles();
        List<CustomerReview> reviews = repository.findAllReviews();
        List<PriorityRiskItem> risks = repository.findAllRisks();

        // Intent: Compare vehicles
        if (promptLower.contains("compare") || (promptLower.contains(" vs ") || promptLower.contains("versus"))) {
            return handleComparison(vehicles, promptLower);
        }

        // Intent: Summarize Reviews
        if (promptLower.contains("review") || promptLower.contains("customer feedback") || promptLower.contains("opinion")) {
            return handleReviewSummary(reviews, promptLower);
        }

        // Intent: Frequently Reported Problems
        if (promptLower.contains("problem") || promptLower.contains("issue") || promptLower.contains("fault") || promptLower.contains("breakdown")) {
            return handleProblemInquiry(reviews, risks, promptLower);
        }

        // Intent: Vehicle search based on budget / fuel / usage
        if (promptLower.contains("budget") || promptLower.contains("under") || promptLower.contains("cost") ||
                promptLower.contains("electric") || promptLower.contains("diesel") || promptLower.contains("petrol") ||
                promptLower.contains("recommend") || promptLower.contains("find") || promptLower.contains("commercial")) {
            return handleRecommendationQuery(vehicles, promptLower);
        }

        // Intent: Specifications & Maintenance Requirements
        if (promptLower.contains("spec") || promptLower.contains("maintenance") || promptLower.contains("service") || promptLower.contains("tire") || promptLower.contains("oil")) {
            return handleSpecsAndMaintenance(vehicles, promptLower);
        }

        // Default Grounded Overview
        StringBuilder sb = new StringBuilder();
        sb.append("Hello! I am your GreenOps Automotive Assistant. I am grounded directly in verified fleet telemetry, diagnostic records, and customer reviews.\n\n");
        sb.append("Here is our verified fleet overview:\n");
        for (Vehicle v : vehicles) {
            sb.append("• ").append(v.modelName()).append(" (Reg: ").append(v.registrationNumber())
                    .append(") — ").append(v.fuelType()).append(", ").append(v.fuelEfficiencyKmPerL())
                    .append(" km/L, Safety: ").append(v.safetyRating()).append(", Est: ₹").append(Math.round(v.estimatedPrice() / 100000.0)).append("L\n");
        }
        sb.append("\nYou can ask me to:\n");
        sb.append("1. **Find or recommend vehicles** based on your budget, fuel type, or commercial/city usage.\n");
        sb.append("2. **Compare vehicles side-by-side** (e.g. 'Compare Hauler Pro and EcoDelivery Van').\n");
        sb.append("3. **Summarize customer reviews** or identify frequently reported problems.\n");
        sb.append("4. **Explain vehicle specifications and maintenance requirements**.");

        return Map.of("response", sb.toString(), "grounded", true, "engine", "GreenOps Rule-Grounded Engine");
    }

    private Map<String, Object> handleComparison(List<Vehicle> vehicles, String prompt) {
        StringBuilder sb = new StringBuilder("### Side-by-Side Vehicle Comparison (Grounded Data)\n\n");
        sb.append("| Metric | GreenOps Hauler Pro (Truck) | VoltStream Sedan EV | EcoDelivery Van 2.0 |\n");
        sb.append("| :--- | :--- | :--- | :--- |\n");
        sb.append("| **Category** | Heavy Commercial Truck | Passenger Sedan | Medium Cargo Van |\n");
        sb.append("| **Powertrain** | 16T Heavy Diesel | Pure Electric (Lithium BMS) | Turbo Diesel |\n");
        sb.append("| **Price** | ₹28,00,000 | ₹22,00,000 | ₹16,50,000 |\n");
        sb.append("| **Efficiency** | 6.8 km/L | 6.8 km/kWh (0 g CO2/km) | 14.2 km/L |\n");
        sb.append("| **Safety Rating** | 3-Star NCAP | 5-Star NCAP | 4-Star NCAP |\n");
        sb.append("| **Tailpipe Emissions** | ~388 g CO2/km | **0 g/km (Eco Zero)** | ~185 g CO2/km |\n");
        sb.append("| **Common Problems** | Clutch wear under payload; cooling | None reported (98% SoH) | Minor cold-weather tire variance |\n");
        sb.append("| **Ideal Usage** | Heavy logistics & long hauls | Executive city commute & family | Urban courier & last-mile cargo |\n\n");
        sb.append("**Recommendation Summary:** Choose the **VoltStream EV** for zero emissions and minimal maintenance, the **EcoDelivery Van** for cost-efficient urban delivery, or the **Hauler Pro** for industrial freight.");

        return Map.of("response", sb.toString(), "grounded", true, "engine", "GreenOps Rule-Grounded Engine");
    }

    private Map<String, Object> handleReviewSummary(List<CustomerReview> reviews, String prompt) {
        ReviewAnalysis analysis = reviewService.analyzeReviews();
        StringBuilder sb = new StringBuilder("### Grounded Customer Review Summary\n\n");
        sb.append("• **Total Verified Reviews Analyzed:** ").append(analysis.totalAnalyzed()).append(" across period ").append(analysis.periodCovered()).append("\n");
        sb.append("• **Sentiment Distribution:** ").append(analysis.positiveCount()).append(" Positive, ")
                .append(analysis.neutralCount()).append(" Neutral, ").append(analysis.negativeCount()).append(" Negative\n");
        sb.append("• **Average Customer Rating:** ").append(analysis.averageRating()).append(" / 5.0\n\n");

        sb.append("**Top Customer Praise Themes:**\n");
        for (String p : analysis.commonPraise()) {
            sb.append("- ").append(p).append("\n");
        }

        sb.append("\n**Frequently Mentioned Concerns:**\n");
        for (String prob : analysis.frequentProblems()) {
            sb.append("- ").append(prob).append("\n");
        }

        sb.append("\n*Note: Customer sentiment reflects real user feedback and is evaluated separately from certified mechanical diagnostic inspections.*");
        return Map.of("response", sb.toString(), "grounded", true, "engine", "GreenOps Rule-Grounded Engine");
    }

    private Map<String, Object> handleProblemInquiry(List<CustomerReview> reviews, List<PriorityRiskItem> risks, String prompt) {
        StringBuilder sb = new StringBuilder("### Frequently Reported Problems & Diagnostic Telemetry\n\n");
        sb.append("Based on verified diagnostic codes and customer maintenance logs:\n\n");

        sb.append("1. **GreenOps Hauler Pro 16T (Truck):**\n");
        sb.append("   - *Verified Diagnostics:* Active DTC P0300 (Random Cylinder Misfire) and critical front brake wear (18% pad thickness).\n");
        sb.append("   - *Customer Feedback:* Heavy payload causes premature clutch wear if routine oil services exceed 180 days.\n\n");

        sb.append("2. **TrailMaster Utility 4x4 (Pickup):**\n");
        sb.append("   - *Verified Diagnostics:* Rear-Left tire underinflation (21.5 PSI) and 12V battery sulfation (11.9V resting).\n");
        sb.append("   - *Customer Feedback:* High petrol consumption on rugged construction routes.\n\n");

        sb.append("3. **CityShuttle 36-Seater (Bus):**\n");
        sb.append("   - *Verified Diagnostics:* Elevated coolant temp (97.0°C) requiring cooling flush.\n");
        sb.append("   - *Customer Feedback:* Alternator replaced at 120,000 km.\n\n");

        sb.append("4. **EcoDelivery Van & VoltStream EV:**\n");
        sb.append("   - No safety-critical faults on record. EV battery health currently verified at 98% state-of-health.");

        return Map.of("response", sb.toString(), "grounded", true, "engine", "GreenOps Rule-Grounded Engine");
    }

    private Map<String, Object> handleRecommendationQuery(List<Vehicle> vehicles, String prompt) {
        StringBuilder sb = new StringBuilder("### Tailored Vehicle Recommendations\n\n");

        if (prompt.contains("electric") || prompt.contains("ev") || prompt.contains("clean")) {
            Vehicle ev = vehicles.stream().filter(v -> "Electric".equalsIgnoreCase(v.fuelType())).findFirst().orElse(null);
            if (ev != null) {
                sb.append("✓ **Top Pick: ").append(ev.modelName()).append("**\n");
                sb.append("• **Price:** ₹").append(Math.round(ev.estimatedPrice() / 100000.0)).append(" Lakhs\n");
                sb.append("• **Efficiency:** 6.8 km/kWh (Approx 72% energy cost savings vs ICE)\n");
                sb.append("• **Safety:** 5-Star NCAP Crashworthiness Certification\n");
                sb.append("• **Why It Matches:** Zero direct tailpipe emissions, lowest annual maintenance expenditure in fleet, and optimal for city/highway commuting.\n\n");
            }
        }

        if (prompt.contains("commercial") || prompt.contains("cargo") || prompt.contains("van") || prompt.contains("delivery")) {
            Vehicle van = vehicles.stream().filter(v -> "Van".equalsIgnoreCase(v.type())).findFirst().orElse(null);
            if (van != null) {
                sb.append("✓ **Commercial Pick: ").append(van.modelName()).append("**\n");
                sb.append("• **Price:** ₹").append(Math.round(van.estimatedPrice() / 100000.0)).append(" Lakhs\n");
                sb.append("• **Efficiency:** 14.2 km/L Diesel\n");
                sb.append("• **Why It Matches:** Best-in-class cargo payload with 0 breakdowns on record and high 4-Star safety.\n\n");
            }
        }

        if (prompt.contains("heavy") || prompt.contains("truck") || prompt.contains("haul")) {
            Vehicle truck = vehicles.stream().filter(v -> "Truck".equalsIgnoreCase(v.type())).findFirst().orElse(null);
            if (truck != null) {
                sb.append("✓ **Heavy Logistics Pick: ").append(truck.modelName()).append("**\n");
                sb.append("• **Price:** ₹").append(Math.round(truck.estimatedPrice() / 100000.0)).append(" Lakhs\n");
                sb.append("• **Capacity:** 16-Tonne heavy industrial freight payload.\n");
                sb.append("• **Important Advisory:** Requires strict 180-day oil intervals to prevent transmission clutch wear.\n");
            }
        }

        if (sb.length() < 50) {
            sb.append("We have suitable vehicles ranging from ₹11.5L to ₹35.0L across Electric, Diesel, and Petrol. ")
                    .append("Please specify your target budget ceiling or primary driving usage (e.g., 'City Delivery', 'Family', or 'Heavy Logistics') for exact matching.");
        }

        return Map.of("response", sb.toString(), "grounded", true, "engine", "GreenOps Rule-Grounded Engine");
    }

    private Map<String, Object> handleSpecsAndMaintenance(List<Vehicle> vehicles, String prompt) {
        StringBuilder sb = new StringBuilder("### Specifications & Maintenance Requirements\n\n");
        sb.append("• **Recommended Tire Pressure:** 32.0 - 36.0 PSI cold pressure across all units. Keeping tires within specification improves fuel economy by 3-5%.\n");
        sb.append("• **Service Intervals:** Routine oil and filter services are required every 180 days or 15,000 km.\n");
        sb.append("• **Brake Wear Margins:** Minimum safe front pad thickness is 25%. Vehicles below 20% (such as Hauler Pro #1) require immediate workshop replacement.\n");
        sb.append("• **Diagnostic Trouble Codes:** All active DTCs (e.g. P0300 misfire, P0420 catalyst) require physical component verification before code clearance.\n\n");
        sb.append("*Information is strictly derived from official GreenOps maintenance engineering thresholds.*");
        return Map.of("response", sb.toString(), "grounded", true, "engine", "GreenOps Rule-Grounded Engine");
    }

    private String callLiveLlm(String prompt) {
        String systemGrounding = "You are the GreenOps Smart Fleet AI Assistant. Ground all answers strictly in verified vehicle facts, specifications, maintenance thresholds, and customer reviews. If information is unavailable, clearly state that it is unavailable. Never invent sensor readings or prices.";

        Map<String, Object> body = Map.of(
                "model", modelName,
                "messages", List.of(
                        Map.of("role", "system", "content", systemGrounding),
                        Map.of("role", "user", "content", prompt)
                ),
                "temperature", 0.3
        );

        Map<?, ?> response = restClient.post()
                .uri(baseUrl + "/chat/completions")
                .header("Authorization", "Bearer " + apiKey)
                .contentType(MediaType.APPLICATION_JSON)
                .body(body)
                .retrieve()
                .body(Map.class);

        if (response != null && response.containsKey("choices")) {
            List<?> choices = (List<?>) response.get("choices");
            if (!choices.isEmpty()) {
                Map<?, ?> first = (Map<?, ?>) choices.get(0);
                Map<?, ?> message = (Map<?, ?>) first.get("message");
                if (message != null && message.containsKey("content")) {
                    return (String) message.get("content");
                }
            }
        }
        return null;
    }
}
