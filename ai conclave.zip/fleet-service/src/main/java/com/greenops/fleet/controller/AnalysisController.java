package com.greenops.fleet.controller;

import com.greenops.fleet.model.FleetAnalysisReport;
import com.greenops.fleet.service.AnalysisService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/analysis")
@CrossOrigin(origins = "*")
public class AnalysisController {

    private final AnalysisService analysisService;

    public AnalysisController(AnalysisService analysisService) {
        this.analysisService = analysisService;
    }

    @GetMapping
    public FleetAnalysisReport getAnalysisReport() {
        return analysisService.generateAnalysisReport();
    }
}
