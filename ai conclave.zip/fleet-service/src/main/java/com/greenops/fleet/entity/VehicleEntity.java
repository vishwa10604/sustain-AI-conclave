package com.greenops.fleet.entity;

import com.greenops.fleet.model.Vehicle;
import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "vehicles")
public class VehicleEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String registrationNumber;

    private String type;
    private String fuelType;

    @Column(name = "model_year")
    private int year;

    private int odometerKm;
    private LocalDate lastServiceDate;
    private String modelName;
    private double estimatedPrice;
    private String safetyRating;

    @Column(name = "fuel_efficiency_km_per_l")
    private double fuelEfficiencyKmPerL;

    public VehicleEntity() {}

    public VehicleEntity(Long id, String registrationNumber, String type, String fuelType,
                         int year, int odometerKm, LocalDate lastServiceDate,
                         String modelName, double estimatedPrice, String safetyRating,
                         double fuelEfficiencyKmPerL) {
        this.id = id;
        this.registrationNumber = registrationNumber;
        this.type = type;
        this.fuelType = fuelType;
        this.year = year;
        this.odometerKm = odometerKm;
        this.lastServiceDate = lastServiceDate;
        this.modelName = modelName;
        this.estimatedPrice = estimatedPrice;
        this.safetyRating = safetyRating;
        this.fuelEfficiencyKmPerL = fuelEfficiencyKmPerL;
    }

    public static VehicleEntity fromModel(Vehicle v) {
        return new VehicleEntity(
                v.id(), v.registrationNumber(), v.type(), v.fuelType(),
                v.year(), v.odometerKm(), v.lastServiceDate(),
                v.modelName(), v.estimatedPrice(), v.safetyRating(),
                v.fuelEfficiencyKmPerL()
        );
    }

    public Vehicle toModel() {
        return new Vehicle(
                id, registrationNumber, type, fuelType, year, odometerKm,
                lastServiceDate, modelName, estimatedPrice, safetyRating,
                fuelEfficiencyKmPerL
        );
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getRegistrationNumber() { return registrationNumber; }
    public void setRegistrationNumber(String registrationNumber) { this.registrationNumber = registrationNumber; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }
    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }
    public int getOdometerKm() { return odometerKm; }
    public void setOdometerKm(int odometerKm) { this.odometerKm = odometerKm; }
    public LocalDate getLastServiceDate() { return lastServiceDate; }
    public void setLastServiceDate(LocalDate lastServiceDate) { this.lastServiceDate = lastServiceDate; }
    public String getModelName() { return modelName; }
    public void setModelName(String modelName) { this.modelName = modelName; }
    public double getEstimatedPrice() { return estimatedPrice; }
    public void setEstimatedPrice(double estimatedPrice) { this.estimatedPrice = estimatedPrice; }
    public String getSafetyRating() { return safetyRating; }
    public void setSafetyRating(String safetyRating) { this.safetyRating = safetyRating; }
    public double getFuelEfficiencyKmPerL() { return fuelEfficiencyKmPerL; }
    public void setFuelEfficiencyKmPerL(double fuelEfficiencyKmPerL) { this.fuelEfficiencyKmPerL = fuelEfficiencyKmPerL; }
}
