package com.greenops.fleet.entity;

import com.greenops.fleet.model.CustomerReview;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "customer_reviews")
public class CustomerReviewEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long vehicleId;
    private String author;
    private int rating;
    private String title;

    @Column(length = 2000)
    private String comment;

    private LocalDate reviewDate;
    private String sentiment; // POSITIVE, NEGATIVE, NEUTRAL

    @Convert(converter = StringListConverter.class)
    @Column(length = 1000)
    private List<String> problemTags;

    @Convert(converter = StringListConverter.class)
    @Column(length = 1000)
    private List<String> praiseTags;

    private boolean verifiedPurchase;
    private boolean flaggedSuspicious;

    @Column(length = 1000)
    private String suspiciousReason;

    public CustomerReviewEntity() {}

    public CustomerReviewEntity(Long id, Long vehicleId, String author, int rating, String title,
                                String comment, LocalDate reviewDate, String sentiment,
                                List<String> problemTags, List<String> praiseTags,
                                boolean verifiedPurchase, boolean flaggedSuspicious, String suspiciousReason) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.author = author;
        this.rating = rating;
        this.title = title;
        this.comment = comment;
        this.reviewDate = reviewDate;
        this.sentiment = sentiment;
        this.problemTags = problemTags;
        this.praiseTags = praiseTags;
        this.verifiedPurchase = verifiedPurchase;
        this.flaggedSuspicious = flaggedSuspicious;
        this.suspiciousReason = suspiciousReason;
    }

    public static CustomerReviewEntity fromModel(CustomerReview r) {
        return new CustomerReviewEntity(
                r.id(), r.vehicleId(), r.author(), r.rating(), r.title(),
                r.comment(), r.reviewDate(), r.sentiment(),
                r.problemTags(), r.praiseTags(),
                r.verifiedPurchase(), r.flaggedSuspicious(), r.suspiciousReason()
        );
    }

    public CustomerReview toModel() {
        return new CustomerReview(
                id, vehicleId, author, rating, title,
                comment, reviewDate, sentiment,
                problemTags != null ? problemTags : List.of(),
                praiseTags != null ? praiseTags : List.of(),
                verifiedPurchase, flaggedSuspicious, suspiciousReason
        );
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    public LocalDate getReviewDate() { return reviewDate; }
    public void setReviewDate(LocalDate reviewDate) { this.reviewDate = reviewDate; }
    public String getSentiment() { return sentiment; }
    public void setSentiment(String sentiment) { this.sentiment = sentiment; }
    public List<String> getProblemTags() { return problemTags; }
    public void setProblemTags(List<String> problemTags) { this.problemTags = problemTags; }
    public List<String> getPraiseTags() { return praiseTags; }
    public void setPraiseTags(List<String> praiseTags) { this.praiseTags = praiseTags; }
    public boolean isVerifiedPurchase() { return verifiedPurchase; }
    public void setVerifiedPurchase(boolean verifiedPurchase) { this.verifiedPurchase = verifiedPurchase; }
    public boolean isFlaggedSuspicious() { return flaggedSuspicious; }
    public void setFlaggedSuspicious(boolean flaggedSuspicious) { this.flaggedSuspicious = flaggedSuspicious; }
    public String getSuspiciousReason() { return suspiciousReason; }
    public void setSuspiciousReason(String suspiciousReason) { this.suspiciousReason = suspiciousReason; }
}
