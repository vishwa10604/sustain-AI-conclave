package com.greenops.fleet.repository;

import com.greenops.fleet.entity.*;
import com.greenops.fleet.model.*;
import com.greenops.fleet.repository.jpa.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class FleetRepository {

    private final VehicleJpaRepository vehicleJpaRepo;
    private final MaintenanceRecordJpaRepository recordJpaRepo;
    private final VehicleHealthJpaRepository healthJpaRepo;
    private final PriorityRiskJpaRepository riskJpaRepo;
    private final CustomerReviewJpaRepository reviewJpaRepo;
    private final SmartNotificationJpaRepository notificationJpaRepo;
    private final UserAccountJpaRepository userJpaRepo;
    private final DriverInspectionJpaRepository inspectionJpaRepo;

    // Fallback in-memory structures for non-Spring unit test instantiation (new FleetRepository())
    private final Map<Long, Vehicle> inMemoryVehicles = new ConcurrentHashMap<>();
    private final Map<Long, MaintenanceRecord> inMemoryRecords = new ConcurrentHashMap<>();
    private final Map<Long, Set<Long>> inMemoryVehicleRecordIndex = new ConcurrentHashMap<>();
    private final Map<Long, VehicleHealth> inMemoryHealthData = new ConcurrentHashMap<>();
    private final Map<Long, PriorityRiskItem> inMemoryPriorityRisks = new ConcurrentHashMap<>();
    private final Map<Long, CustomerReview> inMemoryReviews = new ConcurrentHashMap<>();
    private final Map<Long, SmartNotification> inMemoryNotifications = new ConcurrentHashMap<>();
    private final Map<String, UserAccount> inMemoryUsers = new ConcurrentHashMap<>();
    private final Map<Long, DriverInspection> inMemoryInspections = new ConcurrentHashMap<>();

    private final AtomicLong vehicleSeq = new AtomicLong(0);
    private final AtomicLong recordSeq = new AtomicLong(0);
    private final AtomicLong riskSeq = new AtomicLong(0);
    private final AtomicLong reviewSeq = new AtomicLong(0);
    private final AtomicLong notificationSeq = new AtomicLong(0);
    private final AtomicLong inspectionSeq = new AtomicLong(0);

    /**
     * Default constructor for unit tests that instantiate `new FleetRepository()` directly without Spring context.
     */
    public FleetRepository() {
        this.vehicleJpaRepo = null;
        this.recordJpaRepo = null;
        this.healthJpaRepo = null;
        this.riskJpaRepo = null;
        this.reviewJpaRepo = null;
        this.notificationJpaRepo = null;
        this.userJpaRepo = null;
        this.inspectionJpaRepo = null;
    }

    /**
     * Spring-managed constructor injecting real database JPA repositories.
     */
    @Autowired
    public FleetRepository(
            VehicleJpaRepository vehicleJpaRepo,
            MaintenanceRecordJpaRepository recordJpaRepo,
            VehicleHealthJpaRepository healthJpaRepo,
            PriorityRiskJpaRepository riskJpaRepo,
            CustomerReviewJpaRepository reviewJpaRepo,
            SmartNotificationJpaRepository notificationJpaRepo,
            UserAccountJpaRepository userJpaRepo,
            DriverInspectionJpaRepository inspectionJpaRepo
    ) {
        this.vehicleJpaRepo = vehicleJpaRepo;
        this.recordJpaRepo = recordJpaRepo;
        this.healthJpaRepo = healthJpaRepo;
        this.riskJpaRepo = riskJpaRepo;
        this.reviewJpaRepo = reviewJpaRepo;
        this.notificationJpaRepo = notificationJpaRepo;
        this.userJpaRepo = userJpaRepo;
        this.inspectionJpaRepo = inspectionJpaRepo;
    }

    public boolean isDatabaseBacked() {
        return vehicleJpaRepo != null;
    }

    // --- Vehicle Management ---
    public List<Vehicle> findAllVehicles() {
        if (isDatabaseBacked()) {
            return vehicleJpaRepo.findAll().stream()
                    .map(VehicleEntity::toModel)
                    .sorted(Comparator.comparing(Vehicle::id))
                    .toList();
        }
        return inMemoryVehicles.values().stream()
                .sorted(Comparator.comparing(Vehicle::id))
                .toList();
    }

    public Optional<Vehicle> findVehicleById(Long id) {
        if (id == null) return Optional.empty();
        if (isDatabaseBacked()) {
            return vehicleJpaRepo.findById(id).map(VehicleEntity::toModel);
        }
        return Optional.ofNullable(inMemoryVehicles.get(id));
    }

    @Transactional
    public Vehicle saveVehicle(Vehicle v) {
        if (isDatabaseBacked()) {
            VehicleEntity entity = VehicleEntity.fromModel(v);
            VehicleEntity saved = vehicleJpaRepo.save(entity);
            return saved.toModel();
        }
        Long id = (v.id() != null) ? v.id() : vehicleSeq.incrementAndGet();
        Vehicle saved = new Vehicle(id, v.registrationNumber(), v.type(), v.fuelType(),
                v.year(), v.odometerKm(), v.lastServiceDate(), v.modelName(), v.estimatedPrice(),
                v.safetyRating(), v.fuelEfficiencyKmPerL());
        inMemoryVehicles.put(id, saved);
        return saved;
    }

    @Transactional
    public boolean deleteVehicle(Long id) {
        if (id == null) return false;
        if (isDatabaseBacked()) {
            if (!vehicleJpaRepo.existsById(id)) {
                return false;
            }
            recordJpaRepo.deleteByVehicleId(id);
            healthJpaRepo.deleteByVehicleId(id);
            riskJpaRepo.deleteByVehicleId(id);
            reviewJpaRepo.deleteByVehicleId(id);
            notificationJpaRepo.deleteByVehicleId(id);
            vehicleJpaRepo.deleteById(id);
            return true;
        }

        Set<Long> recordIds = inMemoryVehicleRecordIndex.remove(id);
        if (recordIds != null) {
            for (Long rId : recordIds) {
                inMemoryRecords.remove(rId);
            }
        }
        inMemoryRecords.values().removeIf(r -> Objects.equals(r.vehicleId(), id));
        inMemoryHealthData.remove(id);
        inMemoryPriorityRisks.values().removeIf(r -> Objects.equals(r.vehicleId(), id));
        inMemoryReviews.values().removeIf(rev -> Objects.equals(rev.vehicleId(), id));
        inMemoryNotifications.values().removeIf(n -> Objects.equals(n.vehicleId(), id));
        return inMemoryVehicles.remove(id) != null;
    }

    // --- Maintenance Records ---
    public List<MaintenanceRecord> findRecordsByVehicleId(Long vehicleId) {
        if (vehicleId == null) return List.of();
        if (isDatabaseBacked()) {
            return recordJpaRepo.findByVehicleIdOrderByServiceDateDesc(vehicleId).stream()
                    .map(MaintenanceRecordEntity::toModel)
                    .toList();
        }
        Set<Long> recordIds = inMemoryVehicleRecordIndex.get(vehicleId);
        if (recordIds == null || recordIds.isEmpty()) {
            return List.of();
        }
        return recordIds.stream()
                .map(inMemoryRecords::get)
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(MaintenanceRecord::serviceDate, Comparator.nullsLast(Comparator.reverseOrder())))
                .toList();
    }

    public List<MaintenanceRecord> findAllRecords() {
        if (isDatabaseBacked()) {
            return recordJpaRepo.findAll().stream()
                    .map(MaintenanceRecordEntity::toModel)
                    .sorted(Comparator.comparing(MaintenanceRecord::serviceDate, Comparator.nullsLast(Comparator.reverseOrder())))
                    .toList();
        }
        return inMemoryRecords.values().stream()
                .sorted(Comparator.comparing(MaintenanceRecord::serviceDate, Comparator.nullsLast(Comparator.reverseOrder())))
                .toList();
    }

    @Transactional
    public MaintenanceRecord saveRecord(MaintenanceRecord r) {
        if (isDatabaseBacked()) {
            MaintenanceRecordEntity entity = MaintenanceRecordEntity.fromModel(r);
            MaintenanceRecordEntity saved = recordJpaRepo.save(entity);
            return saved.toModel();
        }
        Long id = (r.id() != null) ? r.id() : recordSeq.incrementAndGet();
        MaintenanceRecord saved = new MaintenanceRecord(id, r.vehicleId(), r.serviceDate(),
                r.type(), r.description(), r.cost());
        inMemoryRecords.put(id, saved);
        if (r.vehicleId() != null) {
            inMemoryVehicleRecordIndex.computeIfAbsent(r.vehicleId(), k -> ConcurrentHashMap.newKeySet()).add(id);
        }
        return saved;
    }

    // --- Vehicle Health & Telemetry ---
    public Optional<VehicleHealth> findHealthByVehicleId(Long vehicleId) {
        if (vehicleId == null) return Optional.empty();
        if (isDatabaseBacked()) {
            return healthJpaRepo.findByVehicleId(vehicleId).map(VehicleHealthEntity::toModel);
        }
        return Optional.ofNullable(inMemoryHealthData.get(vehicleId));
    }

    @Transactional
    public VehicleHealth saveHealth(VehicleHealth vh) {
        if (vh.vehicleId() == null) return vh;
        if (isDatabaseBacked()) {
            VehicleHealthEntity entity = VehicleHealthEntity.fromModel(vh);
            VehicleHealthEntity saved = healthJpaRepo.save(entity);
            return saved.toModel();
        }
        inMemoryHealthData.put(vh.vehicleId(), vh);
        return vh;
    }

    // --- Priority Risk Items ---
    public List<PriorityRiskItem> findAllRisks() {
        if (isDatabaseBacked()) {
            return riskJpaRepo.findAll().stream()
                    .map(PriorityRiskItemEntity::toModel)
                    .sorted(Comparator.comparingInt(PriorityRiskItem::riskScore).reversed())
                    .toList();
        }
        return inMemoryPriorityRisks.values().stream()
                .sorted(Comparator.comparingInt(PriorityRiskItem::riskScore).reversed())
                .toList();
    }

    public List<PriorityRiskItem> findRisksByPriority(String priority) {
        if (priority == null || priority.equalsIgnoreCase("ALL")) {
            return findAllRisks();
        }
        if (isDatabaseBacked()) {
            return riskJpaRepo.findByPriorityIgnoreCaseOrderByRiskScoreDesc(priority).stream()
                    .map(PriorityRiskItemEntity::toModel)
                    .toList();
        }
        return inMemoryPriorityRisks.values().stream()
                .filter(r -> r.priority().equalsIgnoreCase(priority))
                .sorted(Comparator.comparingInt(PriorityRiskItem::riskScore).reversed())
                .toList();
    }

    public List<PriorityRiskItem> findRisksByVehicleId(Long vehicleId) {
        if (vehicleId == null) return List.of();
        if (isDatabaseBacked()) {
            return riskJpaRepo.findByVehicleIdOrderByRiskScoreDesc(vehicleId).stream()
                    .map(PriorityRiskItemEntity::toModel)
                    .toList();
        }
        return inMemoryPriorityRisks.values().stream()
                .filter(r -> Objects.equals(r.vehicleId(), vehicleId))
                .sorted(Comparator.comparingInt(PriorityRiskItem::riskScore).reversed())
                .toList();
    }

    @Transactional
    public PriorityRiskItem saveRisk(PriorityRiskItem item) {
        if (isDatabaseBacked()) {
            PriorityRiskItemEntity entity = PriorityRiskItemEntity.fromModel(item);
            if (entity.getLastUpdated() == null) entity.setLastUpdated(LocalDateTime.now());
            if (entity.getStatus() == null) entity.setStatus("Open");
            PriorityRiskItemEntity saved = riskJpaRepo.save(entity);
            return saved.toModel();
        }
        Long id = (item.id() != null) ? item.id() : riskSeq.incrementAndGet();
        PriorityRiskItem saved = new PriorityRiskItem(
                id, item.vehicleId(), item.vehicleModel(), item.registrationNumber(),
                item.riskCategory(), item.priority(), item.detectedIssue(),
                item.measuredValue(), item.expectedRange(), item.riskScore(),
                item.reason(), item.recommendedAction(), item.detectedDate(),
                item.lastUpdated() != null ? item.lastUpdated() : LocalDateTime.now(),
                item.status() != null ? item.status() : "Open"
        );
        inMemoryPriorityRisks.put(id, saved);
        return saved;
    }

    @Transactional
    public Optional<PriorityRiskItem> updateRiskStatus(Long riskId, String newStatus) {
        if (isDatabaseBacked()) {
            Optional<PriorityRiskItemEntity> opt = riskJpaRepo.findById(riskId);
            if (opt.isEmpty()) return Optional.empty();
            PriorityRiskItemEntity entity = opt.get();
            entity.setStatus(newStatus != null ? newStatus : "Open");
            entity.setLastUpdated(LocalDateTime.now());
            return Optional.of(riskJpaRepo.save(entity).toModel());
        }
        PriorityRiskItem current = inMemoryPriorityRisks.get(riskId);
        if (current == null) return Optional.empty();
        PriorityRiskItem updated = current.withStatus(newStatus);
        inMemoryPriorityRisks.put(riskId, updated);
        return Optional.of(updated);
    }

    // --- Customer Reviews ---
    public List<CustomerReview> findAllReviews() {
        if (isDatabaseBacked()) {
            return reviewJpaRepo.findAll().stream()
                    .map(CustomerReviewEntity::toModel)
                    .sorted(Comparator.comparing(CustomerReview::reviewDate, Comparator.nullsLast(Comparator.reverseOrder())))
                    .toList();
        }
        return inMemoryReviews.values().stream()
                .sorted(Comparator.comparing(CustomerReview::reviewDate).reversed())
                .toList();
    }

    public List<CustomerReview> findReviewsByVehicleId(Long vehicleId) {
        if (vehicleId == null) return List.of();
        if (isDatabaseBacked()) {
            return reviewJpaRepo.findByVehicleIdOrderByReviewDateDesc(vehicleId).stream()
                    .map(CustomerReviewEntity::toModel)
                    .toList();
        }
        return inMemoryReviews.values().stream()
                .filter(r -> Objects.equals(r.vehicleId(), vehicleId))
                .sorted(Comparator.comparing(CustomerReview::reviewDate).reversed())
                .toList();
    }

    @Transactional
    public CustomerReview saveReview(CustomerReview r) {
        if (isDatabaseBacked()) {
            CustomerReviewEntity entity = CustomerReviewEntity.fromModel(r);
            if (entity.getReviewDate() == null) entity.setReviewDate(LocalDate.now());
            CustomerReviewEntity saved = reviewJpaRepo.save(entity);
            return saved.toModel();
        }
        Long id = (r.id() != null) ? r.id() : reviewSeq.incrementAndGet();
        CustomerReview saved = new CustomerReview(
                id, r.vehicleId(), r.author(), r.rating(), r.title(), r.comment(),
                r.reviewDate() != null ? r.reviewDate() : LocalDate.now(),
                r.sentiment(), r.problemTags(), r.praiseTags(),
                r.verifiedPurchase(), r.flaggedSuspicious(), r.suspiciousReason()
        );
        inMemoryReviews.put(id, saved);
        return saved;
    }

    // --- Smart Notifications ---
    public List<SmartNotification> findAllNotifications() {
        if (isDatabaseBacked()) {
            return notificationJpaRepo.findAllByOrderByTimestampDesc().stream()
                    .map(SmartNotificationEntity::toModel)
                    .toList();
        }
        return inMemoryNotifications.values().stream()
                .sorted(Comparator.comparing(SmartNotification::timestamp).reversed())
                .toList();
    }

    @Transactional
    public SmartNotification saveNotification(SmartNotification n) {
        if (isDatabaseBacked()) {
            SmartNotificationEntity entity = SmartNotificationEntity.fromModel(n);
            if (entity.getTimestamp() == null) entity.setTimestamp(LocalDateTime.now());
            if (entity.getStatus() == null) entity.setStatus("Open");
            SmartNotificationEntity saved = notificationJpaRepo.save(entity);
            return saved.toModel();
        }
        Long id = (n.id() != null) ? n.id() : notificationSeq.incrementAndGet();
        SmartNotification saved = new SmartNotification(
                id, n.vehicleId(), n.registrationNumber(), n.priority(),
                n.title(), n.message(),
                n.timestamp() != null ? n.timestamp() : LocalDateTime.now(),
                n.acknowledged(), n.status() != null ? n.status() : "Open"
        );
        inMemoryNotifications.put(id, saved);
        return saved;
    }

    @Transactional
    public Optional<SmartNotification> acknowledgeNotification(Long id) {
        if (isDatabaseBacked()) {
            Optional<SmartNotificationEntity> opt = notificationJpaRepo.findById(id);
            if (opt.isEmpty()) return Optional.empty();
            SmartNotificationEntity entity = opt.get();
            entity.setAcknowledged(true);
            return Optional.of(notificationJpaRepo.save(entity).toModel());
        }
        SmartNotification current = inMemoryNotifications.get(id);
        if (current == null) return Optional.empty();
        SmartNotification updated = current.withAcknowledged(true);
        inMemoryNotifications.put(id, updated);
        return Optional.of(updated);
    }

    @Transactional
    public Optional<SmartNotification> resolveNotification(Long id) {
        if (isDatabaseBacked()) {
            Optional<SmartNotificationEntity> opt = notificationJpaRepo.findById(id);
            if (opt.isEmpty()) return Optional.empty();
            SmartNotificationEntity entity = opt.get();
            entity.setStatus("Resolved");
            return Optional.of(notificationJpaRepo.save(entity).toModel());
        }
        SmartNotification current = inMemoryNotifications.get(id);
        if (current == null) return Optional.empty();
        SmartNotification updated = current.withStatus("Resolved");
        inMemoryNotifications.put(id, updated);
        return Optional.of(updated);
    }

    // --- User Accounts ---
    public Optional<UserAccount> findUserByEmail(String email) {
        if (email == null) return Optional.empty();
        if (isDatabaseBacked()) {
            return userJpaRepo.findByEmailIgnoreCase(email.trim()).map(UserAccountEntity::toModel);
        }
        return Optional.ofNullable(inMemoryUsers.get(email.toLowerCase().trim()));
    }

    @Transactional
    public UserAccount saveUser(UserAccount u) {
        if (u == null || u.email() == null) return u;
        if (isDatabaseBacked()) {
            UserAccountEntity entity = UserAccountEntity.fromModel(u);
            return userJpaRepo.save(entity).toModel();
        }
        inMemoryUsers.put(u.email().toLowerCase().trim(), u);
        return u;
    }

    public List<UserAccount> findAllUsers() {
        if (isDatabaseBacked()) {
            return userJpaRepo.findAll().stream()
                    .map(UserAccountEntity::toModel)
                    .map(UserAccount::withoutPassword)
                    .toList();
        }
        return inMemoryUsers.values().stream().map(UserAccount::withoutPassword).toList();
    }

    // --- Driver Inspections ---
    @Transactional
    public DriverInspection saveInspection(DriverInspection insp) {
        if (isDatabaseBacked()) {
            DriverInspectionEntity entity = DriverInspectionEntity.fromModel(insp);
            if (entity.getTimestamp() == null) entity.setTimestamp(LocalDateTime.now());
            if (entity.getSafetyVerdict() == null) entity.setSafetyVerdict("CLEARED_FOR_ROUTE");
            DriverInspectionEntity saved = inspectionJpaRepo.save(entity);
            return saved.toModel();
        }
        Long id = (insp.id() != null) ? insp.id() : inspectionSeq.incrementAndGet();
        DriverInspection saved = new DriverInspection(
                id, insp.vehicleId(), insp.driverName(), insp.vehicleReg(),
                insp.tirePressureVisualOk(), insp.oilLevelChecked(),
                insp.brakesResponsive(), insp.lightsOperational(),
                insp.odometerKm(), insp.remarks(),
                insp.timestamp() != null ? insp.timestamp() : LocalDateTime.now(),
                insp.safetyVerdict() != null ? insp.safetyVerdict() : "CLEARED_FOR_ROUTE"
        );
        inMemoryInspections.put(id, saved);
        return saved;
    }

    public List<DriverInspection> findAllInspections() {
        if (isDatabaseBacked()) {
            return inspectionJpaRepo.findAllByOrderByTimestampDesc().stream()
                    .map(DriverInspectionEntity::toModel)
                    .toList();
        }
        return inMemoryInspections.values().stream()
                .sorted(Comparator.comparing(DriverInspection::timestamp).reversed())
                .toList();
    }

    public List<DriverInspection> findInspectionsByVehicleId(Long vehicleId) {
        if (vehicleId == null) return List.of();
        if (isDatabaseBacked()) {
            return inspectionJpaRepo.findByVehicleIdOrderByTimestampDesc(vehicleId).stream()
                    .map(DriverInspectionEntity::toModel)
                    .toList();
        }
        return inMemoryInspections.values().stream()
                .filter(i -> Objects.equals(i.vehicleId(), vehicleId))
                .sorted(Comparator.comparing(DriverInspection::timestamp).reversed())
                .toList();
    }

    // --- Database Diagnostic Metrics ---
    public Map<String, Object> getDatabaseStatistics() {
        Map<String, Object> stats = new LinkedHashMap<>();
        boolean dbActive = isDatabaseBacked();
        stats.put("databaseType", dbActive ? "H2 Relational Database (Spring Data JPA / Hibernate)" : "In-Memory ConcurrentHashMap");
        stats.put("isDatabaseActive", dbActive);
        stats.put("h2ConsoleUrl", "/h2-console");
        stats.put("jdbcUrl", "jdbc:h2:mem:fleetdb");
        stats.put("dialect", "org.hibernate.dialect.H2Dialect");

        Map<String, Long> tables = new LinkedHashMap<>();
        if (dbActive) {
            tables.put("vehicles", vehicleJpaRepo.count());
            tables.put("maintenance_records", recordJpaRepo.count());
            tables.put("vehicle_health", healthJpaRepo.count());
            tables.put("priority_risk_items", riskJpaRepo.count());
            tables.put("customer_reviews", reviewJpaRepo.count());
            tables.put("smart_notifications", notificationJpaRepo.count());
            tables.put("user_accounts", userJpaRepo.count());
            tables.put("driver_inspections", inspectionJpaRepo.count());
        } else {
            tables.put("vehicles", (long) inMemoryVehicles.size());
            tables.put("maintenance_records", (long) inMemoryRecords.size());
            tables.put("vehicle_health", (long) inMemoryHealthData.size());
            tables.put("priority_risk_items", (long) inMemoryPriorityRisks.size());
            tables.put("customer_reviews", (long) inMemoryReviews.size());
            tables.put("smart_notifications", (long) inMemoryNotifications.size());
            tables.put("user_accounts", (long) inMemoryUsers.size());
            tables.put("driver_inspections", (long) inMemoryInspections.size());
        }
        stats.put("tables", tables);
        stats.put("totalRecords", tables.values().stream().mapToLong(Long::longValue).sum());
        return stats;
    }
}
