package com.greenops.fleet.controller;

import com.greenops.fleet.service.AiCustomerAssistantService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin(origins = "*")
public class AiChatController {

    private final AiCustomerAssistantService aiService;

    public AiChatController(AiCustomerAssistantService aiService) {
        this.aiService = aiService;
    }

    @PostMapping("/chat")
    public Map<String, Object> chat(@RequestBody Map<String, String> request) {
        String message = request.getOrDefault("message", "");
        return aiService.askAssistant(message);
    }
}
