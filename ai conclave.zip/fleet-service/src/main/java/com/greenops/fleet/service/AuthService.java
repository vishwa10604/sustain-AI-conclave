package com.greenops.fleet.service;

import com.greenops.fleet.model.DriverInspection;
import com.greenops.fleet.model.SmartNotification;
import com.greenops.fleet.model.UserAccount;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {

    private final FleetRepository repository;
    private final Map<String, UserAccount> activeSessions = new ConcurrentHashMap<>();

    public AuthService(FleetRepository repository) {
        this.repository = repository;
    }

    public Map<String, Object> login(String email, String password) {
        if (email == null || password == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Email and password are required");
        }

        UserAccount user = repository.findUserByEmail(email)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password"));

        if (!user.password().equals(password)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        }

        String token = "GO-AUTH-" + UUID.randomUUID();
        activeSessions.put(token, user);

        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("email", user.email());
        result.put("name", user.name());
        result.put("role", user.role());
        result.put("verified", user.verified());
        result.put("verificationDoc", user.verificationDoc());
        result.put("assignedVehicleReg", user.assignedVehicleReg());
        result.put("assignedVehicleId", user.assignedVehicleId());
        return result;
    }

    public UserAccount getCurrentUser(String token) {
        if (token == null || !activeSessions.containsKey(token)) {
            // Default demo fallback is Vehicle Owner
            return repository.findUserByEmail("owner@greenoops.com")
                    .map(UserAccount::withoutPassword)
                    .orElse(new UserAccount("usr-guest", "guest@greenoops.com", "Guest User", null, "VEHICLE_OWNER", false, "Unverified", "ALL", null));
        }
        return activeSessions.get(token).withoutPassword();
    }

    public void logout(String token) {
        if (token != null) {
            activeSessions.remove(token);
        }
    }

    public DriverInspection submitInspection(DriverInspection insp) {
        if (insp.vehicleId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "vehicleId is required");
        }

        String reg = insp.vehicleReg();
        if ((reg == null || reg.isBlank()) && insp.vehicleId() != null) {
            reg = repository.findVehicleById(insp.vehicleId())
                    .map(com.greenops.fleet.model.Vehicle::registrationNumber)
                    .orElse("TN-VEH-" + insp.vehicleId());
        }

        String verdict;
        if (!insp.brakesResponsive() || !insp.tirePressureVisualOk()) {
            verdict = "ACTION_REQUIRED";
            // Create automated notification for Owner
            repository.saveNotification(new SmartNotification(
                    null, insp.vehicleId(), reg, "CRITICAL",
                    "Driver Pre-Trip Alert: " + reg,
                    "Driver " + insp.driverName() + " reported safety defects: " + (insp.remarks() != null ? insp.remarks() : "Safety item failure"),
                    LocalDateTime.now(), false, "Open"
            ));
        } else {
            verdict = "CLEARED_FOR_ROUTE";
        }

        DriverInspection toSave = new DriverInspection(
                null, insp.vehicleId(), insp.driverName(), reg,
                insp.tirePressureVisualOk(), insp.oilLevelChecked(),
                insp.brakesResponsive(), insp.lightsOperational(),
                insp.odometerKm(), insp.remarks(), LocalDateTime.now(), verdict
        );

        return repository.saveInspection(toSave);
    }

    public List<DriverInspection> getInspections(Long vehicleId) {
        if (vehicleId != null) {
            return repository.findInspectionsByVehicleId(vehicleId);
        }
        return repository.findAllInspections();
    }
}
