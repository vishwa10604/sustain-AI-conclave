package com.greenops.fleet.model;

import java.time.LocalDateTime;

public record DriverInspection(
        Long id,
        Long vehicleId,
        String driverName,
        String vehicleReg,
        boolean tirePressureVisualOk,
        boolean oilLevelChecked,
        boolean brakesResponsive,
        boolean lightsOperational,
        int odometerKm,
        String remarks,
        LocalDateTime timestamp,
        String safetyVerdict // "CLEARED_FOR_ROUTE", "ACTION_REQUIRED", "GROUNDED"
) {
}
