package com.greenops.fleet.model;

import java.time.LocalDate;

public record MaintenanceRecord(
        Long id,
        Long vehicleId,
        LocalDate serviceDate,
        String type,          // ROUTINE_SERVICE, BREAKDOWN_REPAIR, TYRE_REPLACEMENT, BATTERY
        String description,
        double cost) {
}
