package com.greenops.fleet.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record PriorityRiskItem(
        Long id,
        Long vehicleId,
        String vehicleModel,
        String registrationNumber,
        String riskCategory, // BRAKING_SAFETY, POWERTRAIN, FLUID_SYSTEMS, TIRE_PRESSURE, ELECTRICAL, SCHEDULED_SERVICE
        String priority,     // HIGH, MEDIUM, LOW
        String detectedIssue,
        String measuredValue,
        String expectedRange,
        int riskScore,
        String reason,
        String recommendedAction,
        LocalDate detectedDate,
        LocalDateTime lastUpdated,
        String status // Open, In Progress, Resolved
) {
    public PriorityRiskItem withStatus(String newStatus) {
        return new PriorityRiskItem(
                id, vehicleId, vehicleModel, registrationNumber, riskCategory, priority,
                detectedIssue, measuredValue, expectedRange, riskScore, reason,
                recommendedAction, detectedDate, LocalDateTime.now(), newStatus
        );
    }
}
