package com.greenops.fleet.entity;

import com.greenops.fleet.model.MaintenanceRecord;
import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "maintenance_records")
public class MaintenanceRecordEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long vehicleId;

    private LocalDate serviceDate;
    private String type;

    @Column(length = 1000)
    private String description;

    private double cost;

    public MaintenanceRecordEntity() {}

    public MaintenanceRecordEntity(Long id, Long vehicleId, LocalDate serviceDate, String type, String description, double cost) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.serviceDate = serviceDate;
        this.type = type;
        this.description = description;
        this.cost = cost;
    }

    public static MaintenanceRecordEntity fromModel(MaintenanceRecord r) {
        return new MaintenanceRecordEntity(r.id(), r.vehicleId(), r.serviceDate(), r.type(), r.description(), r.cost());
    }

    public MaintenanceRecord toModel() {
        return new MaintenanceRecord(id, vehicleId, serviceDate, type, description, cost);
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public LocalDate getServiceDate() { return serviceDate; }
    public void setServiceDate(LocalDate serviceDate) { this.serviceDate = serviceDate; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; }
}
