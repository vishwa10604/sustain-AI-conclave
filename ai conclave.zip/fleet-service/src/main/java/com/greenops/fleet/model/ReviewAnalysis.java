package com.greenops.fleet.model;

import java.util.List;
import java.util.Map;

public record ReviewAnalysis(
        int totalAnalyzed,
        int positiveCount,
        int negativeCount,
        int neutralCount,
        double averageRating,
        String periodCovered,
        List<String> frequentProblems,
        List<String> commonPraise,
        List<String> reliabilityThemes,
        List<String> mileageFeedback,
        int duplicateCount,
        List<String> suspiciousPatterns,
        Map<String, Double> modelSatisfactionRatings) {
}
