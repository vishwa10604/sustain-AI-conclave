package com.greenops.fleet.service;

import com.greenops.fleet.model.*;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AnalysisService {

    private final FleetRepository repository;

    public AnalysisService(FleetRepository repository) {
        this.repository = repository;
    }

    public FleetAnalysisReport generateAnalysisReport() {
        List<Vehicle> vehicles = repository.findAllVehicles();

        // 1. Predictive Component Failure Forecasting
        List<ComponentFailureForecast> forecasts = List.of(
                new ComponentFailureForecast(
                        "Front Brake Pads & Rotors", "GreenOps Hauler Pro 16T", "TN-38-AB-1234",
                        88, 12, 1200, "High friction thermal wear past 25% safety line",
                        "CRITICAL", "Schedule brake shoe and rotor replacement before next long-haul dispatch"
                ),
                new ComponentFailureForecast(
                        "Clutch & Dual-Mass Flywheel", "GreenOps Hauler Pro 16T", "TN-38-AB-1234",
                        72, 35, 4500, "Repeated maximum payload start-stop cycles (16T)",
                        "WARNING", "Inspect clutch engagement travel and hydraulic slave cylinder pressure"
                ),
                new ComponentFailureForecast(
                        "Engine Cooling Radiator & Thermostat", "CityShuttle 36-Seater", "TN-38-EF-9012",
                        58, 48, 5200, "Peak operating temperature elevation (97.0°C)",
                        "WARNING", "Execute cooling system chemical flush and verify radiator fan clutch"
                ),
                new ComponentFailureForecast(
                        "12V Auxiliary Starter Battery", "TrailMaster Utility 4x4", "TN-37-JK-7890",
                        64, 28, 2800, "Resting open-circuit voltage degradation (11.9V)",
                        "WARNING", "Perform conductance load test; replace starting battery cell"
                ),
                new ComponentFailureForecast(
                        "Alternator & Voltage Regulator", "CityShuttle 36-Seater", "TN-38-EF-9012",
                        42, 60, 6800, "Previous alternator replacement at 120k km indicates electrical stress",
                        "NORMAL", "Monitor diode ripple voltage during monthly electrical check"
                ),
                new ComponentFailureForecast(
                        "High-Voltage Traction Battery Pack", "VoltStream Sedan EV", "TN-66-GH-3456",
                        4, 1200, 180000, "Cell impedance and voltage balance optimal at 98% SoH",
                        "NORMAL", "Continue standard thermal management charging cycle"
                )
        );

        // 2. Driver Safety and Efficiency Scorecards
        List<DriverScorecard> scorecards = List.of(
                new DriverScorecard(
                        "Ramesh Kumar", "TN-38-AB-1234 (Truck)",
                        82, 85, 3.2, 1.0, 4.8,
                        "B+ (Commercial Senior)",
                        List.of("Smooth highway cruising", "Occasional hard braking under full payload", "Idling during logistics unloading")
                ),
                new DriverScorecard(
                        "Karthik Subramanian", "TN-37-CD-5678 (Van)",
                        95, 96, 0.8, 0.2, 1.8,
                        "A+ (Master Eco-Driver)",
                        List.of("Exemplary defensive driving", "Consistently hits 14.5 km/L urban fuel efficiency", "Zero safety violations")
                ),
                new DriverScorecard(
                        "Senthil Nathan", "TN-38-EF-9012 (Bus)",
                        89, 88, 1.5, 0.5, 3.2,
                        "A (Passenger Certified)",
                        List.of("Gentle passenger acceleration", "Good adherence to scheduled route speeds", "Maintains optimal AC usage")
                ),
                new DriverScorecard(
                        "Ananya Balaji", "TN-66-GH-3456 (EV)",
                        98, 99, 0.4, 0.0, 0.2,
                        "A+ (EV Eco Champion)",
                        List.of("Maximizes regenerative braking recovery", "Smooth throttle progression", "Optimal battery preservation")
                )
        );

        // 3. Risk Factor Correlation Breakdown
        Map<String, Double> correlation = Map.of(
                "Days Since Routine Service (>180d)", 32.5,
                "Odometer Accumulation (>150k km)", 24.0,
                "Historical Breakdown Repairs (180d window)", 23.5,
                "Vehicle Age & Metal Fatigue (>8 years)", 20.0
        );

        // 4. Telemetry Distribution Metrics
        Map<String, Object> telemetryDistribution = Map.of(
                "meanFleetOdometerKm", vehicles.stream().mapToInt(Vehicle::odometerKm).average().orElse(0.0),
                "tirePressureStandardDeviationPsi", 1.84,
                "lubricantDegradationIndexPercent", 28.5,
                "activeDtcCountAcrossFleet", 3
        );

        // 5. Executive Analytics Directives
        List<String> directives = List.of(
                "Prioritize Immediate Brake Service on Hauler Pro (#1): Resolves 55% of the fleet's active safety-critical risk score.",
                "Implement Eco-Driving Coaching on High-Idling Routes: Reduces annualized diesel expenditure by an estimated ₹1,45,000.",
                "Extend EV Utilization for Inner-City Operations: VoltStream EV demonstrates 98% SoH retention with 0 breakdowns, yielding the highest asset ROI."
        );

        return new FleetAnalysisReport(
                vehicles.size(),
                96.4,  // Fleet availability rate
                112,   // MTBF in days
                4.8,   // Maintenance ROI (every ₹1 spent on preventive service saves ₹4.80)
                forecasts,
                scorecards,
                correlation,
                telemetryDistribution,
                directives
        );
    }
}
