package com.greenops.fleet.controller;

import com.greenops.fleet.model.MaintenanceRecord;
import com.greenops.fleet.model.RiskReport;
import com.greenops.fleet.model.Vehicle;
import com.greenops.fleet.service.MaintenanceRiskService;
import com.greenops.fleet.service.VehicleService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
@CrossOrigin(origins = "*")
public class VehicleController {

    private final VehicleService vehicleService;
    private final MaintenanceRiskService riskService;

    public VehicleController(VehicleService vehicleService, MaintenanceRiskService riskService) {
        this.vehicleService = vehicleService;
        this.riskService = riskService;
    }

    @GetMapping("/maintenance/all")
    public List<MaintenanceRecord> getAllMaintenance() {
        return vehicleService.getAllMaintenance();
    }

    @GetMapping
    public List<Vehicle> getAll() {
        return vehicleService.getAll();
    }

    @GetMapping("/{id}")
    public Vehicle getById(@PathVariable Long id) {
        return vehicleService.getById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Vehicle create(@RequestBody Vehicle vehicle) {
        return vehicleService.create(vehicle);
    }

    @PutMapping("/{id}")
    public Vehicle update(@PathVariable Long id, @RequestBody Vehicle vehicle) {
        return vehicleService.update(id, vehicle);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        vehicleService.delete(id);
    }

    @GetMapping("/{id}/maintenance")
    public List<MaintenanceRecord> getMaintenance(@PathVariable Long id) {
        return vehicleService.getMaintenance(id);
    }

    @PostMapping("/{id}/maintenance")
    @ResponseStatus(HttpStatus.CREATED)
    public MaintenanceRecord addMaintenance(@PathVariable Long id,
                                            @RequestBody MaintenanceRecord record) {
        return vehicleService.addMaintenance(id, record);
    }

    @GetMapping("/{id}/risk")
    public RiskReport getRisk(@PathVariable Long id) {
        return riskService.assess(id);
    }

    @GetMapping("/risk-summary")
    public List<RiskReport> getRiskSummary() {
        return riskService.assessAll();
    }
}
