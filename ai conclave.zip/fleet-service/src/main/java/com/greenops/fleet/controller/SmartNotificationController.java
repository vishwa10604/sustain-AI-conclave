package com.greenops.fleet.controller;

import com.greenops.fleet.model.SmartNotification;
import com.greenops.fleet.service.SmartNotificationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "*")
public class SmartNotificationController {

    private final SmartNotificationService notificationService;

    public SmartNotificationController(SmartNotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping
    public List<SmartNotification> getAll() {
        return notificationService.getAllNotifications();
    }

    @PostMapping("/{id}/acknowledge")
    public SmartNotification acknowledge(@PathVariable Long id) {
        return notificationService.acknowledge(id);
    }

    @PostMapping("/{id}/resolve")
    public SmartNotification resolve(@PathVariable Long id) {
        return notificationService.resolve(id);
    }
}
