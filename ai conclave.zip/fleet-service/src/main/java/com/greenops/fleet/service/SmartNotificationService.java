package com.greenops.fleet.service;

import com.greenops.fleet.model.SmartNotification;
import com.greenops.fleet.repository.FleetRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class SmartNotificationService {

    private final FleetRepository repository;

    public SmartNotificationService(FleetRepository repository) {
        this.repository = repository;
    }

    public List<SmartNotification> getAllNotifications() {
        return repository.findAllNotifications();
    }

    public SmartNotification acknowledge(Long id) {
        return repository.acknowledgeNotification(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Notification not found: " + id));
    }

    public SmartNotification resolve(Long id) {
        return repository.resolveNotification(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Notification not found: " + id));
    }
}
