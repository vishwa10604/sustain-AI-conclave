package com.greenops.fleet.controller;

import com.greenops.fleet.model.CustomerPreference;
import com.greenops.fleet.model.VehicleRecommendation;
import com.greenops.fleet.service.VehicleRecommendationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recommendations")
@CrossOrigin(origins = "*")
public class VehicleRecommendationController {

    private final VehicleRecommendationService recommendationService;

    public VehicleRecommendationController(VehicleRecommendationService recommendationService) {
        this.recommendationService = recommendationService;
    }

    @PostMapping
    public List<VehicleRecommendation> getRecommendations(@RequestBody(required = false) CustomerPreference preference) {
        CustomerPreference pref = preference != null ? preference : new CustomerPreference(null, null, null, null, null, null, null, null);
        return recommendationService.getRecommendations(pref);
    }
}
