package com.greenops.fleet.entity;

import com.greenops.fleet.model.VehicleHealth;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "vehicle_health")
public class VehicleHealthEntity {

    @Id
    private Long vehicleId;

    private Double oilLevelPercent;
    private String oilPressureStatus;
    private String oilCondition;
    private LocalDate lastOilChange;
    private LocalDate nextOilChange;
    private String oilMaintenanceStatus;

    private double tirePressureFlPsi;
    private double tirePressureFrPsi;
    private double tirePressureRlPsi;
    private double tirePressureRrPsi;
    private double recommendedTirePressurePsi;
    private double tireTreadFlMm;
    private double tireTreadFrMm;
    private double tireTreadRlMm;
    private double tireTreadRrMm;
    private String tireInspectionStatus;

    private double coolantTempCelsius;
    private double batteryHealthPercent;
    private double batteryVoltage;
    private double brakePadFrontPercent;
    private double brakePadRearPercent;
    private String brakeFluidStatus;

    @Convert(converter = StringListConverter.class)
    @Column(length = 2000)
    private List<String> diagnosticTroubleCodes;

    @Column(name = "fuel_efficiency_km_per_l")
    private double fuelEfficiencyKmPerL;
    private int odometerKm;
    private String overallHealthStatus;
    private String dataSource;
    private LocalDateTime lastUpdated;

    public VehicleHealthEntity() {}

    public VehicleHealthEntity(Long vehicleId, Double oilLevelPercent, String oilPressureStatus, String oilCondition,
                               LocalDate lastOilChange, LocalDate nextOilChange, String oilMaintenanceStatus,
                               double tirePressureFlPsi, double tirePressureFrPsi, double tirePressureRlPsi, double tirePressureRrPsi,
                               double recommendedTirePressurePsi, double tireTreadFlMm, double tireTreadFrMm, double tireTreadRlMm, double tireTreadRrMm,
                               String tireInspectionStatus, double coolantTempCelsius, double batteryHealthPercent, double batteryVoltage,
                               double brakePadFrontPercent, double brakePadRearPercent, String brakeFluidStatus,
                               List<String> diagnosticTroubleCodes, double fuelEfficiencyKmPerL, int odometerKm,
                               String overallHealthStatus, String dataSource, LocalDateTime lastUpdated) {
        this.vehicleId = vehicleId;
        this.oilLevelPercent = oilLevelPercent;
        this.oilPressureStatus = oilPressureStatus;
        this.oilCondition = oilCondition;
        this.lastOilChange = lastOilChange;
        this.nextOilChange = nextOilChange;
        this.oilMaintenanceStatus = oilMaintenanceStatus;
        this.tirePressureFlPsi = tirePressureFlPsi;
        this.tirePressureFrPsi = tirePressureFrPsi;
        this.tirePressureRlPsi = tirePressureRlPsi;
        this.tirePressureRrPsi = tirePressureRrPsi;
        this.recommendedTirePressurePsi = recommendedTirePressurePsi;
        this.tireTreadFlMm = tireTreadFlMm;
        this.tireTreadFrMm = tireTreadFrMm;
        this.tireTreadRlMm = tireTreadRlMm;
        this.tireTreadRrMm = tireTreadRrMm;
        this.tireInspectionStatus = tireInspectionStatus;
        this.coolantTempCelsius = coolantTempCelsius;
        this.batteryHealthPercent = batteryHealthPercent;
        this.batteryVoltage = batteryVoltage;
        this.brakePadFrontPercent = brakePadFrontPercent;
        this.brakePadRearPercent = brakePadRearPercent;
        this.brakeFluidStatus = brakeFluidStatus;
        this.diagnosticTroubleCodes = diagnosticTroubleCodes;
        this.fuelEfficiencyKmPerL = fuelEfficiencyKmPerL;
        this.odometerKm = odometerKm;
        this.overallHealthStatus = overallHealthStatus;
        this.dataSource = dataSource;
        this.lastUpdated = lastUpdated;
    }

    public static VehicleHealthEntity fromModel(VehicleHealth h) {
        return new VehicleHealthEntity(
                h.vehicleId(), h.oilLevelPercent(), h.oilPressureStatus(), h.oilCondition(),
                h.lastOilChange(), h.nextOilChange(), h.oilMaintenanceStatus(),
                h.tirePressureFlPsi(), h.tirePressureFrPsi(), h.tirePressureRlPsi(), h.tirePressureRrPsi(),
                h.recommendedTirePressurePsi(), h.tireTreadFlMm(), h.tireTreadFrMm(), h.tireTreadRlMm(), h.tireTreadRrMm(),
                h.tireInspectionStatus(), h.coolantTempCelsius(), h.batteryHealthPercent(), h.batteryVoltage(),
                h.brakePadFrontPercent(), h.brakePadRearPercent(), h.brakeFluidStatus(),
                h.diagnosticTroubleCodes(), h.fuelEfficiencyKmPerL(), h.odometerKm(),
                h.overallHealthStatus(), h.dataSource(), h.lastUpdated()
        );
    }

    public VehicleHealth toModel() {
        return new VehicleHealth(
                vehicleId, oilLevelPercent, oilPressureStatus, oilCondition,
                lastOilChange, nextOilChange, oilMaintenanceStatus,
                tirePressureFlPsi, tirePressureFrPsi, tirePressureRlPsi, tirePressureRrPsi,
                recommendedTirePressurePsi, tireTreadFlMm, tireTreadFrMm, tireTreadRlMm, tireTreadRrMm,
                tireInspectionStatus, coolantTempCelsius, batteryHealthPercent, batteryVoltage,
                brakePadFrontPercent, brakePadRearPercent, brakeFluidStatus,
                diagnosticTroubleCodes != null ? diagnosticTroubleCodes : List.of(),
                fuelEfficiencyKmPerL, odometerKm, overallHealthStatus, dataSource, lastUpdated
        );
    }

    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public Double getOilLevelPercent() { return oilLevelPercent; }
    public void setOilLevelPercent(Double oilLevelPercent) { this.oilLevelPercent = oilLevelPercent; }
    public String getOilPressureStatus() { return oilPressureStatus; }
    public void setOilPressureStatus(String oilPressureStatus) { this.oilPressureStatus = oilPressureStatus; }
    public String getOilCondition() { return oilCondition; }
    public void setOilCondition(String oilCondition) { this.oilCondition = oilCondition; }
    public LocalDate getLastOilChange() { return lastOilChange; }
    public void setLastOilChange(LocalDate lastOilChange) { this.lastOilChange = lastOilChange; }
    public LocalDate getNextOilChange() { return nextOilChange; }
    public void setNextOilChange(LocalDate nextOilChange) { this.nextOilChange = nextOilChange; }
    public String getOilMaintenanceStatus() { return oilMaintenanceStatus; }
    public void setOilMaintenanceStatus(String oilMaintenanceStatus) { this.oilMaintenanceStatus = oilMaintenanceStatus; }
    public double getTirePressureFlPsi() { return tirePressureFlPsi; }
    public void setTirePressureFlPsi(double tirePressureFlPsi) { this.tirePressureFlPsi = tirePressureFlPsi; }
    public double getTirePressureFrPsi() { return tirePressureFrPsi; }
    public void setTirePressureFrPsi(double tirePressureFrPsi) { this.tirePressureFrPsi = tirePressureFrPsi; }
    public double getTirePressureRlPsi() { return tirePressureRlPsi; }
    public void setTirePressureRlPsi(double tirePressureRlPsi) { this.tirePressureRlPsi = tirePressureRlPsi; }
    public double getTirePressureRrPsi() { return tirePressureRrPsi; }
    public void setTirePressureRrPsi(double tirePressureRrPsi) { this.tirePressureRrPsi = tirePressureRrPsi; }
    public double getRecommendedTirePressurePsi() { return recommendedTirePressurePsi; }
    public void setRecommendedTirePressurePsi(double recommendedTirePressurePsi) { this.recommendedTirePressurePsi = recommendedTirePressurePsi; }
    public double getTireTreadFlMm() { return tireTreadFlMm; }
    public void setTireTreadFlMm(double tireTreadFlMm) { this.tireTreadFlMm = tireTreadFlMm; }
    public double getTireTreadFrMm() { return tireTreadFrMm; }
    public void setTireTreadFrMm(double tireTreadFrMm) { this.tireTreadFrMm = tireTreadFrMm; }
    public double getTireTreadRlMm() { return tireTreadRlMm; }
    public void setTireTreadRlMm(double tireTreadRlMm) { this.tireTreadRlMm = tireTreadRlMm; }
    public double getTireTreadRrMm() { return tireTreadRrMm; }
    public void setTireTreadRrMm(double tireTreadRrMm) { this.tireTreadRrMm = tireTreadRrMm; }
    public String getTireInspectionStatus() { return tireInspectionStatus; }
    public void setTireInspectionStatus(String tireInspectionStatus) { this.tireInspectionStatus = tireInspectionStatus; }
    public double getCoolantTempCelsius() { return coolantTempCelsius; }
    public void setCoolantTempCelsius(double coolantTempCelsius) { this.coolantTempCelsius = coolantTempCelsius; }
    public double getBatteryHealthPercent() { return batteryHealthPercent; }
    public void setBatteryHealthPercent(double batteryHealthPercent) { this.batteryHealthPercent = batteryHealthPercent; }
    public double getBatteryVoltage() { return batteryVoltage; }
    public void setBatteryVoltage(double batteryVoltage) { this.batteryVoltage = batteryVoltage; }
    public double getBrakePadFrontPercent() { return brakePadFrontPercent; }
    public void setBrakePadFrontPercent(double brakePadFrontPercent) { this.brakePadFrontPercent = brakePadFrontPercent; }
    public double getBrakePadRearPercent() { return brakePadRearPercent; }
    public void setBrakePadRearPercent(double brakePadRearPercent) { this.brakePadRearPercent = brakePadRearPercent; }
    public String getBrakeFluidStatus() { return brakeFluidStatus; }
    public void setBrakeFluidStatus(String brakeFluidStatus) { this.brakeFluidStatus = brakeFluidStatus; }
    public List<String> getDiagnosticTroubleCodes() { return diagnosticTroubleCodes; }
    public void setDiagnosticTroubleCodes(List<String> diagnosticTroubleCodes) { this.diagnosticTroubleCodes = diagnosticTroubleCodes; }
    public double getFuelEfficiencyKmPerL() { return fuelEfficiencyKmPerL; }
    public void setFuelEfficiencyKmPerL(double fuelEfficiencyKmPerL) { this.fuelEfficiencyKmPerL = fuelEfficiencyKmPerL; }
    public int getOdometerKm() { return odometerKm; }
    public void setOdometerKm(int odometerKm) { this.odometerKm = odometerKm; }
    public String getOverallHealthStatus() { return overallHealthStatus; }
    public void setOverallHealthStatus(String overallHealthStatus) { this.overallHealthStatus = overallHealthStatus; }
    public String getDataSource() { return dataSource; }
    public void setDataSource(String dataSource) { this.dataSource = dataSource; }
    public LocalDateTime getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDateTime lastUpdated) { this.lastUpdated = lastUpdated; }
}
