package com.greenops.fleet.model;

public record ComponentFailureForecast(
        String componentName,
        String vehicleModel,
        String registrationNumber,
        int failureProbabilityPercent, // 0 - 100%
        int estimatedDaysToFailure,
        int estimatedKmRemaining,
        String keyStressFactor,
        String severityLevel, // "CRITICAL", "WARNING", "NORMAL"
        String recommendedPreventiveAction
) {
}
