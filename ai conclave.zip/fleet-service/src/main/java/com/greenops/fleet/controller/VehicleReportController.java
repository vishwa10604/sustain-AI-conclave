package com.greenops.fleet.controller;

import com.greenops.fleet.service.VehicleHealthReportService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class VehicleReportController {

    private final VehicleHealthReportService reportService;

    public VehicleReportController(VehicleHealthReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/{vehicleId}")
    public Map<String, Object> getReport(@PathVariable Long vehicleId) {
        return reportService.generateComprehensiveReport(vehicleId);
    }
}
