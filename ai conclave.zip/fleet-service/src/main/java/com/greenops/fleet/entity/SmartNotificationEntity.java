package com.greenops.fleet.entity;

import com.greenops.fleet.model.SmartNotification;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "smart_notifications")
public class SmartNotificationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long vehicleId;
    private String registrationNumber;
    private String priority; // CRITICAL, WARNING, INFO
    private String title;

    @Column(length = 1000)
    private String message;

    private LocalDateTime timestamp;
    private boolean acknowledged;
    private String status; // Open, Resolved

    public SmartNotificationEntity() {}

    public SmartNotificationEntity(Long id, Long vehicleId, String registrationNumber, String priority,
                                  String title, String message, LocalDateTime timestamp,
                                  boolean acknowledged, String status) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.registrationNumber = registrationNumber;
        this.priority = priority;
        this.title = title;
        this.message = message;
        this.timestamp = timestamp;
        this.acknowledged = acknowledged;
        this.status = status;
    }

    public static SmartNotificationEntity fromModel(SmartNotification n) {
        return new SmartNotificationEntity(
                n.id(), n.vehicleId(), n.registrationNumber(), n.priority(),
                n.title(), n.message(), n.timestamp(), n.acknowledged(), n.status()
        );
    }

    public SmartNotification toModel() {
        return new SmartNotification(
                id, vehicleId, registrationNumber, priority,
                title, message, timestamp, acknowledged, status
        );
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public String getRegistrationNumber() { return registrationNumber; }
    public void setRegistrationNumber(String registrationNumber) { this.registrationNumber = registrationNumber; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public boolean isAcknowledged() { return acknowledged; }
    public void setAcknowledged(boolean acknowledged) { this.acknowledged = acknowledged; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
