package com.greenops.fleet.entity;

import com.greenops.fleet.model.UserAccount;
import jakarta.persistence.*;

@Entity
@Table(name = "user_accounts")
public class UserAccountEntity {

    @Id
    private String id;

    @Column(nullable = false, unique = true)
    private String email;

    private String name;
    private String password;
    private String role; // "DRIVER" or "VEHICLE_OWNER"
    private boolean verified;
    private String verificationDoc;
    private String assignedVehicleReg;
    private Long assignedVehicleId;

    public UserAccountEntity() {}

    public UserAccountEntity(String id, String email, String name, String password, String role,
                             boolean verified, String verificationDoc, String assignedVehicleReg,
                             Long assignedVehicleId) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.password = password;
        this.role = role;
        this.verified = verified;
        this.verificationDoc = verificationDoc;
        this.assignedVehicleReg = assignedVehicleReg;
        this.assignedVehicleId = assignedVehicleId;
    }

    public static UserAccountEntity fromModel(UserAccount u) {
        return new UserAccountEntity(
                u.id(), u.email(), u.name(), u.password(), u.role(),
                u.verified(), u.verificationDoc(), u.assignedVehicleReg(),
                u.assignedVehicleId()
        );
    }

    public UserAccount toModel() {
        return new UserAccount(
                id, email, name, password, role, verified,
                verificationDoc, assignedVehicleReg, assignedVehicleId
        );
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public boolean isVerified() { return verified; }
    public void setVerified(boolean verified) { this.verified = verified; }
    public String getVerificationDoc() { return verificationDoc; }
    public void setVerificationDoc(String verificationDoc) { this.verificationDoc = verificationDoc; }
    public String getAssignedVehicleReg() { return assignedVehicleReg; }
    public void setAssignedVehicleReg(String assignedVehicleReg) { this.assignedVehicleReg = assignedVehicleReg; }
    public Long getAssignedVehicleId() { return assignedVehicleId; }
    public void setAssignedVehicleId(Long assignedVehicleId) { this.assignedVehicleId = assignedVehicleId; }
}
