package com.greenops.fleet.entity;

import com.greenops.fleet.model.DriverInspection;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "driver_inspections")
public class DriverInspectionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long vehicleId;
    private String driverName;
    private String vehicleReg;
    private boolean tirePressureVisualOk;
    private boolean oilLevelChecked;
    private boolean brakesResponsive;
    private boolean lightsOperational;
    private int odometerKm;

    @Column(length = 1000)
    private String remarks;

    private LocalDateTime timestamp;
    private String safetyVerdict;

    public DriverInspectionEntity() {}

    public DriverInspectionEntity(Long id, Long vehicleId, String driverName, String vehicleReg,
                                  boolean tirePressureVisualOk, boolean oilLevelChecked,
                                  boolean brakesResponsive, boolean lightsOperational,
                                  int odometerKm, String remarks, LocalDateTime timestamp,
                                  String safetyVerdict) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.driverName = driverName;
        this.vehicleReg = vehicleReg;
        this.tirePressureVisualOk = tirePressureVisualOk;
        this.oilLevelChecked = oilLevelChecked;
        this.brakesResponsive = brakesResponsive;
        this.lightsOperational = lightsOperational;
        this.odometerKm = odometerKm;
        this.remarks = remarks;
        this.timestamp = timestamp;
        this.safetyVerdict = safetyVerdict;
    }

    public static DriverInspectionEntity fromModel(DriverInspection i) {
        return new DriverInspectionEntity(
                i.id(), i.vehicleId(), i.driverName(), i.vehicleReg(),
                i.tirePressureVisualOk(), i.oilLevelChecked(),
                i.brakesResponsive(), i.lightsOperational(),
                i.odometerKm(), i.remarks(), i.timestamp(),
                i.safetyVerdict()
        );
    }

    public DriverInspection toModel() {
        return new DriverInspection(
                id, vehicleId, driverName, vehicleReg,
                tirePressureVisualOk, oilLevelChecked,
                brakesResponsive, lightsOperational,
                odometerKm, remarks, timestamp, safetyVerdict
        );
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public String getDriverName() { return driverName; }
    public void setDriverName(String driverName) { this.driverName = driverName; }
    public String getVehicleReg() { return vehicleReg; }
    public void setVehicleReg(String vehicleReg) { this.vehicleReg = vehicleReg; }
    public boolean isTirePressureVisualOk() { return tirePressureVisualOk; }
    public void setTirePressureVisualOk(boolean tirePressureVisualOk) { this.tirePressureVisualOk = tirePressureVisualOk; }
    public boolean isOilLevelChecked() { return oilLevelChecked; }
    public void setOilLevelChecked(boolean oilLevelChecked) { this.oilLevelChecked = oilLevelChecked; }
    public boolean isBrakesResponsive() { return brakesResponsive; }
    public void setBrakesResponsive(boolean brakesResponsive) { this.brakesResponsive = brakesResponsive; }
    public boolean isLightsOperational() { return lightsOperational; }
    public void setLightsOperational(boolean lightsOperational) { this.lightsOperational = lightsOperational; }
    public int getOdometerKm() { return odometerKm; }
    public void setOdometerKm(int odometerKm) { this.odometerKm = odometerKm; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public String getSafetyVerdict() { return safetyVerdict; }
    public void setSafetyVerdict(String safetyVerdict) { this.safetyVerdict = safetyVerdict; }
}
