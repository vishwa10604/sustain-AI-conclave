package com.greenops.fleet.model;

public record UserAccount(
        String id,
        String email,
        String name,
        String password,
        String role, // "DRIVER" or "VEHICLE_OWNER"
        boolean verified,
        String verificationDoc, // e.g. "DL-TN-38-2018-99214" or "RC-TN-GO-77821"
        String assignedVehicleReg,
        Long assignedVehicleId
) {
    public UserAccount withoutPassword() {
        return new UserAccount(id, email, name, null, role, verified, verificationDoc, assignedVehicleReg, assignedVehicleId);
    }
}
