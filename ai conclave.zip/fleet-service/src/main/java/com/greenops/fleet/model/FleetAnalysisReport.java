package com.greenops.fleet.model;

import java.util.List;
import java.util.Map;

public record FleetAnalysisReport(
        int totalVehiclesMonitored,
        double fleetAvailabilityRatePercent,
        int meanTimeBetweenFailuresDays,
        double maintenanceRoiMultiplier, // e.g. 4.8x (every ₹1 saves ₹4.80)
        List<ComponentFailureForecast> predictiveForecasts,
        List<DriverScorecard> driverScorecards,
        Map<String, Double> riskFactorCorrelation, // Correlation of factors to total risk
        Map<String, Object> telemetryDistribution, // Mean oil, tire pressure variance
        List<String> executiveAnalyticsDirectives
) {
}
